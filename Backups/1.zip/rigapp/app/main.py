from __future__ import annotations
import datetime as dt

from fastapi import FastAPI, Depends, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, JSONResponse, RedirectResponse
from sqlalchemy.orm import Session
from sqlalchemy import select
from starlette.staticfiles import StaticFiles
from urllib.parse import urlencode

from .db import engine, Base, get_db
from .auth import router as auth_router, require_reader, require_writer
from .routers.stock import router as stock_router
from .routers.restock import router as restock_router
from .routers.bits import router as bits_router
from .routers.usage import router as usage_router
from .routers.prestart import router as prestart_router
from .routers.equipment import router as equipment_router
from .routers.travel import router as travel_router
from .routers.refuel import router as refuel_router
from .routers.handover import router as handover_router
from .models import Settings, StockItem, RestockItem, Bit, EquipmentFault, BitStatus
from .audit import recent_logs

app = FastAPI(title="Rig App")

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import HTMLResponse

class AutoCSSMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        resp = await call_next(request)

        # Only modify HTMLResponse (skip StreamingResponse/JSON/etc.)
        if not isinstance(resp, HTMLResponse):
            return resp

        # Decode current HTML
        try:
            charset = getattr(resp, "charset", "utf-8")
            text = resp.body.decode(charset) if isinstance(resp.body, (bytes, bytearray)) else str(resp.body)
        except Exception:
            # If anything is odd, bail out safely
            return resp

        # Inject <head> with viewport + stylesheet if missing
        if "<head" not in text:
            head = (
                '<head>'
                '<meta name="viewport" content="width=device-width, initial-scale=1">'
                '<link rel="stylesheet" href="/static/style.css">'
                '</head>'
            )
            text = text.replace("<html>", f"<html>{head}", 1)
        elif "static/style.css" not in text:
            text = text.replace(
                "<head>",
                '<head>'
                '<meta name="viewport" content="width=device-width, initial-scale=1">'
                '<link rel="stylesheet" href="/static/style.css">',
                1,
            )

        # Rebuild response preserving status & headers
        return HTMLResponse(
            text,
            status_code=resp.status_code,
            headers=dict(resp.headers),
        )

# (re)register the middleware once
app.add_middleware(AutoCSSMiddleware)

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

# Static (simple CSS)
app.mount("/static", StaticFiles(directory="rigapp/app/static"), name="static")

# Routers
app.include_router(auth_router)
app.include_router(stock_router)
app.include_router(restock_router)
app.include_router(bits_router)
app.include_router(usage_router)
app.include_router(prestart_router)
app.include_router(equipment_router)
app.include_router(travel_router)
app.include_router(refuel_router)
app.include_router(handover_router)

# Root (dashboard)
@app.get("/", response_class=HTMLResponse)
def root(ok: bool = Depends(require_reader), db: Session = Depends(get_db)):
    low_stock = db.scalars(
        select(StockItem).where(StockItem.on_rig_qty <= (StockItem.min_qty + StockItem.buffer_qty))
    ).all()
    open_restock = db.scalars(
        select(RestockItem).where(RestockItem.is_closed == False)  # noqa: E712
    ).all()
    bits_attention = db.scalars(
        select(Bit).where(Bit.status.in_([BitStatus.NEEDS_RESHARPEN, BitStatus.VERY_USED]))
    ).all()
    open_faults = db.scalars(
        select(EquipmentFault).where(EquipmentFault.is_resolved == False)  # noqa: E712
    ).all()

    def badge(label: str, value: int, color: str) -> str:
        return f"<a class='card' href='#{label}' style='border-left:6px solid {color};'><b>{label}:</b> {value}</a>"

    cards = []
    cards.append(f"<a class='card' href='/stock' style='border-left:6px solid #8b0000;'><b>Low/Critical stock:</b> {len(low_stock)}</a>")
    cards.append(f"<a class='card' href='/restock' style='border-left:6px solid #1f6feb;'><b>Open restock:</b> {len(open_restock)}</a>")
    cards.append(f"<a class='card' href='/bits' style='border-left:6px solid #f9844a;'><b>Bits attention:</b> {len(bits_attention)}</a>")
    cards.append(f"<a class='card' href='/equipment' style='border-left:6px solid #e0a800;'><b>Open equipment faults:</b> {len(open_faults)}</a>")

    quick = [
        ("+ Stock", "/stock/new"),
        ("+ Restock", "/restock/new"),
        ("+ Bit", "/bits/new"),
        ("+ Usage", "/usage/new"),
        ("+ Prestart", "/prestart/new"),
        ("+ Travel", "/travel/new"),
        ("+ Refuel", "/refuel/new"),
        ("+ Handover", "/handover/new"),
    ]
    quick_links = " · ".join([f"<a href='{u}'>{t}</a>" for t, u in quick])

    logs = recent_logs(db, limit=10)
    log_lines = [f"<li>#{a.id} {a.when} — {a.actor} — {a.entity}[{a.entity_id}] {a.action} — {a.summary}</li>" for a in logs]

    html = f"""
    <html>
    <head>
      <link rel="stylesheet" href="/static/style.css">
    </head>
    <body class="container">
      <h1>Hello, Rig!</h1>
      <p>FastAPI skeleton is running.</p>

      <div class="cards">
        {"".join(cards)}
      </div>

      <div class="quick">{quick_links}</div>

      <h3>Navigation</h3>
      <ul>
        <li><a href="/stock">Stock</a> · <a href="/stock/search">Search</a> · <a href="/stock/import">Import CSV</a> · <a href="/stock/export.csv">Export CSV</a></li>
        <li><a href="/restock">Restock</a> · <a href="/restock/export.csv">Export CSV</a></li>
        <li><a href="/bits">Bits</a> · <a href="/usage">Usage</a></li>
        <li><a href="/prestart">Prestart</a></li>
        <li><a href="/equipment">Equipment</a> (open faults by default) · <a href="/equipment?show=all">show=all</a></li>
        <li><a href="/travel">Travel</a> · <a href="/refuel">Refuel</a> · <a href="/handover">Handover</a></li>
        <li><a href="/debug/routes">Debug: Routes</a> · <a href="/debug/settings">Debug: Settings</a></li>
        <li><form method="post" action="/auth/logout" style="display:inline;"><button type="submit">Logout</button></form></li>
      </ul>

      <h3>Recent Activity</h3>
      <ul>
        {''.join(log_lines) or "<li>Nothing yet.</li>"}
      </ul>
    </body></html>
    """
    return HTMLResponse(html)

# Health must be plain text "ok" for tests
@app.get("/health", response_class=PlainTextResponse)
def health():
    return "ok"

# Protected test route (accepts test cookie names)
@app.get("/protected/test", response_class=HTMLResponse)
def protected_test(request: Request):
    if request.cookies.get("crew_ok") == "1" or request.cookies.get("crew_auth") == "1":
        return HTMLResponse("Protected OK")
    params = urlencode({"next": "/protected/test"})
    return RedirectResponse(url=f"/auth/pin?{params}", status_code=303)

@app.get("/debug/routes", response_class=HTMLResponse)
def debug_routes():
    data = [{"path": r.path, "name": r.name} for r in app.routes]
    import json
    return HTMLResponse(json.dumps(data))

@app.get("/debug/settings", response_class=JSONResponse)
def debug_settings(db: Session = Depends(get_db)):
    s = db.scalar(select(Settings).limit(1))
    if not s:
        return {"detail": "No Settings row"}
    return {
        "status": "ok",
        "timezone": s.timezone,
        "reminder_horizon_days": s.reminder_horizon_days,
        "has_pin_hash": bool(s.crew_pin_hash),
    }

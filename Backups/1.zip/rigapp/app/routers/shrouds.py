from __future__ import annotations
from fastapi import APIRouter, Depends, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from sqlalchemy import select, desc

from ..db import get_db
from ..models import Shroud, ShroudCondition
from ..auth import require_writer, current_actor
from ..audit import write_log, snapshot

router = APIRouter(prefix="/shrouds", tags=["shrouds"])

def cond_badge(c: ShroudCondition) -> str:
    color = "#2a9d8f" if c == ShroudCondition.NEW else "#f9844a"
    return f"<span style='color:#fff;background:{color};padding:2px 6px;border-radius:4px;'>{c.value}</span>"

@router.get("", response_class=HTMLResponse)
def list_shrouds(db: Session = Depends(get_db)):
    rows = []
    for s in db.scalars(select(Shroud).order_by(desc(Shroud.updated_at))).all():
        badge = cond_badge(s.condition)
        at = "Yes" if s.at_rig else "No"
        rows.append(
            f"<tr>"
            f"<td>{s.size_mm:g} mm</td>"
            f"<td>{badge}</td>"
            f"<td>{at}<br><small>{s.notes or ''}</small></td>"
            f"<td><a href='/shrouds/{s.id}/edit'>Edit</a> | "
            f"<form method='post' action='/shrouds/{s.id}/delete' style='display:inline;' onsubmit='return confirm(\"Delete shroud {s.size_mm:g}?\");'>"
            f"<button type='submit'>Delete</button></form></td>"
            f"</tr>"
        )
    html = f"""
    <html><body style="font-family: system-ui; max-width: 900px; margin: 2rem auto;">
      <h2>Shrouds</h2>
      <a href="/shrouds/new" style="float:right;">+ New shroud</a>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>Size</th><th>Condition</th><th>At rig / Notes</th><th>Actions</th></tr></thead>
        <tbody>{''.join(rows) or "<tr><td colspan='4'>No shrouds.</td></tr>"}</tbody>
      </table>
      <p style="margin-top:1rem;"><a href="/">Back</a></p>
    </body></html>
    """
    return HTMLResponse(html)

@router.get("/new", response_class=HTMLResponse)
def new_shroud_form(ok: bool = Depends(require_writer)):
    html = """
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>New Shroud</h2>
      <form method="post" action="/shrouds/new">
        <label>Size (mm)<br><input name="size_mm" type="number" step="any" required></label><br><br>
        <label>Condition<br>
          <select name="condition">
            <option value="NEW">New</option>
            <option value="USED">Used</option>
          </select>
        </label><br><br>
        <label>At rig <input type="checkbox" name="at_rig" checked></label><br><br>
        <label>Notes<br><textarea name="notes" rows="3"></textarea></label><br><br>
        <button type="submit">Create</button>
        <a href="/shrouds">Cancel</a>
      </form>
    </body></html>
    """
    return HTMLResponse(html)

@router.post("/new")
def create_shroud(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    size_mm: float = Form(...),
    condition: str = Form("NEW"),
    at_rig: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    s = Shroud(
        size_mm=size_mm,
        condition=ShroudCondition(condition),
        at_rig=bool(at_rig),
        notes=notes.strip(),
    )
    db.add(s)
    db.flush()
    write_log(db, actor=actor, entity="Shroud", entity_id=s.id, action="CREATED", after_obj=s, summary=f"Shroud {s.size_mm:g}mm created")
    db.commit()
    return RedirectResponse(url="/shrouds", status_code=303)

@router.get("/{sid}/edit", response_class=HTMLResponse)
def edit_shroud_form(sid: int, ok: bool = Depends(require_writer), db: Session = Depends(get_db)):
    s = db.get(Shroud, sid)
    if not s:
        raise HTTPException(status_code=404, detail="Not found")
    def sel(v: str) -> str:
        return "selected" if s.condition.value == v else ""
    checked = "checked" if s.at_rig else ""
    html = f"""
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>Edit Shroud</h2>
      <form method="post" action="/shrouds/{s.id}/edit">
        <label>Size (mm)<br><input name="size_mm" type="number" step="any" value="{s.size_mm}"></label><br><br>
        <label>Condition<br>
          <select name="condition">
            <option value="NEW" {sel('NEW')}>New</option>
            <option value="USED" {sel('USED')}>Used</option>
          </select>
        </label><br><br>
        <label>At rig <input type="checkbox" name="at_rig" {checked}></label><br><br>
        <label>Notes<br><textarea name="notes" rows="3">{s.notes or ''}</textarea></label><br><br>
        <button type="submit">Save</button>
        <a href="/shrouds">Cancel</a>
      </form>
    </body></html>
    """
    return HTMLResponse(html)

@router.post("/{sid}/edit")
def edit_shroud(
    sid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    size_mm: float = Form(...),
    condition: str = Form("NEW"),
    at_rig: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    s = db.get(Shroud, sid)
    if not s:
        return RedirectResponse(url="/shrouds", status_code=303)
    before = snapshot(s)
    s.size_mm = size_mm
    s.condition = ShroudCondition(condition)
    s.at_rig = bool(at_rig)
    s.notes = notes.strip()
    write_log(db, actor=actor, entity="Shroud", entity_id=s.id, action="UPDATED", before_obj=before, after_obj=s, summary=f"Shroud {s.size_mm:g}mm updated")
    db.commit()
    return RedirectResponse(url="/shrouds", status_code=303)

@router.post("/{sid}/delete")
def delete_shroud(sid: int, ok: bool = Depends(require_writer), actor: str = Depends(current_actor), db: Session = Depends(get_db)):
    s = db.get(Shroud, sid)
    if not s:
        return RedirectResponse(url="/shrouds", status_code=303)
    before = snapshot(s)
    size = s.size_mm
    db.delete(s)
    write_log(db, actor=actor, entity="Shroud", entity_id=sid, action="DELETED", before_obj=before, after_obj={}, summary=f"Shroud {size:g}mm deleted")
    db.commit()
    return RedirectResponse(url="/shrouds", status_code=303)

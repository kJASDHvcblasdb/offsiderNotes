from __future__ import annotations
import csv
import io
import datetime as dt
from math import ceil

from fastapi import APIRouter, Depends, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import select, or_, desc

from ..db import get_db
from ..models import Bit, BitStatus, DailyUsage, GeneralNote
from ..auth import require_writer, current_actor
from ..audit import write_log, snapshot

router = APIRouter(prefix="/bits", tags=["bits"])

LIFE_WARN_FRACTION = 0.8  # 80% → VERY_USED suggestion

def status_badge(status: BitStatus) -> str:
    color = {
        BitStatus.NEW: "#2a9d8f",
        BitStatus.USED: "#f9c74f",
        BitStatus.VERY_USED: "#f9844a",
        BitStatus.NEEDS_RESHARPEN: "#1f6feb",
        BitStatus.SHARPENED: "#007f5f",
        BitStatus.EOL: "#8b0000",
    }[status]
    label = status.value.replace("_", " ").title()
    return f"<span style='color:#fff;background:{color};padding:2px 6px;border-radius:4px;'>{label}</span>"

def project_remaining_and_eta(bit: Bit) -> tuple[str, str]:
    """Remaining meters and ETA (if assumed_m_per_day is set)."""
    if not bit.expected_life_m:
        return ("", "")
    remaining = float(bit.expected_life_m) - float(bit.total_meters or 0.0)
    if remaining <= 0:
        return ("remaining ~ 0m", "ETA EOL ~ now")
    rem_txt = f"remaining ~ {remaining:.0f}m"
    if bit.assumed_m_per_day and bit.assumed_m_per_day > 0:
        days_left = remaining / bit.assumed_m_per_day
        eta = dt.date.today() + dt.timedelta(days=ceil(days_left))
        return (rem_txt, f"ETA EOL ~ {eta.isoformat()}")
    return (rem_txt, "")

@router.get("", response_class=HTMLResponse)
def list_bits(q: str | None = None, status: str | None = None, db: Session = Depends(get_db)):
    stmt = select(Bit).order_by(desc(Bit.updated_at))
    if q:
        like = f"%{q}%"
        stmt = stmt.where(or_(Bit.bit_number.ilike(like), Bit.notes.ilike(like)))
    bits = db.scalars(stmt).all()
    rows = []
    for b in bits:
        if status and (b.status.value != status.upper()):
            continue
        badge = status_badge(b.status)
        life_txt = f"{b.total_meters:g}m"
        if b.expected_life_m:
            frac = (b.total_meters or 0) / b.expected_life_m
            life_txt = f"{b.total_meters:g}m / {b.expected_life_m:g}m ({frac*100:.0f}%)"

        rem_txt, eta_txt = project_remaining_and_eta(b)
        calc_bits = [x for x in (rem_txt, eta_txt) if x]
        if b.assumed_m_per_day:
            calc_bits.insert(0, f"{b.assumed_m_per_day:g} m/day (assumed)")
        calc = " · ".join(calc_bits)

        rows.append(
            f"<tr>"
            f"<td>{b.bit_number}<br><small>{b.diameter_mm or ''} mm</small></td>"
            f"<td>{badge}<br><small>last used {b.last_used or '-'}</small></td>"
            f"<td>{life_txt}<br><small>{b.notes or ''}</small></td>"
            f"<td><small>{calc}</small></td>"
            f"<td>"
            f"<form method='post' action='/bits/{b.id}/add_meters' style='display:inline;margin-right:6px;'>"
            f"<input type='number' step='any' name='meters' placeholder='+m' required style='width:6em;'/>"
            f"<button type='submit'>+ meters</button>"
            f"</form>"
            f"<a href='/usage/new?bit_id={b.id}'>+ Usage</a> | "
            f"<a href='/bits/{b.id}/edit'>Edit</a> | "
            f"<form method='post' action='/bits/{b.id}/mark/need-resharpen' style='display:inline;margin-left:6px;' onsubmit='return confirm(\"Mark {b.bit_number} as NEEDS RESHARPENING?\");'>"
            f"<button type='submit'>Needs resharpen</button>"
            f"</form>"
            f" "
            f"<form method='post' action='/bits/{b.id}/mark/sharpened' style='display:inline;margin-left:6px;' onsubmit='return confirm(\"Mark {b.bit_number} as SHARPENED?\");'>"
            f"<button type='submit'>Sharpened</button>"
            f"</form>"
            f" | "
            f"<form method='post' action='/bits/{b.id}/delete' style='display:inline;' onsubmit='return confirm(\"Delete {b.bit_number}?\");'>"
            f"<button type='submit'>Delete</button>"
            f"</form>"
            f"</td>"
            f"</tr>"
        )
    html = f"""
    <html><body style="font-family: system-ui; max-width: 1200px; margin: 2rem auto;">
      <h2>Bits</h2>
      <form method="get" action="/bits" style="margin-bottom:1rem;">
        <input name="q" placeholder="Search serial/notes" value="{q or ''}"/>
        <select name="status">
          <option value="">All</option>
          {"".join([f"<option value='{s.value}' {'selected' if status==s.value else ''}>{s.value.title().replace('_',' ')}</option>" for s in BitStatus])}
        </select>
        <button type="submit">Search</button>
        <a href="/bits/new" style="float:right;">+ New bit</a>
      </form>
      <p><a href="/bits/export.csv">Export CSV</a></p>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>Serial / Diameter</th><th>Status</th><th>Meters / Notes</th><th>Projection</th><th>Actions</th></tr></thead>
        <tbody>{''.join(rows) or "<tr><td colspan='5'>No bits.</td></tr>"}</tbody>
      </table>
      <p style="margin-top:1rem;"><a href="/">Back</a></p>
    </body></html>
    """
    return HTMLResponse(html)

@router.get("/new", response_class=HTMLResponse)
def new_bit_form(ok: bool = Depends(require_writer)):
    html = """
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>New Bit</h2>
      <form method="post" action="/bits/new">
        <label>Serial number (printed on bit)<br><input name="bit_number" required></label><br><br>
        <label>Diameter (mm)<br><input name="diameter_mm" type="number" step="any"></label><br><br>
        <label>Status<br>
          <select name="status">
            <option value="NEW">New</option>
            <option value="USED">Used</option>
            <option value="VERY_USED">Very Used</option>
            <option value="NEEDS_RESHARPEN">Needs Resharpening</option>
            <option value="SHARPENED">Sharpened</option>
            <option value="EOL">EOL</option>
          </select>
        </label><br><br>
        <label>Expected life (m, optional)<br><input name="expected_life_m" type="number" step="any"></label><br><br>
        <label>Assumed meters/day (optional)<br><input name="assumed_m_per_day" type="number" step="any"></label><br><br>
        <label>Notes<br><textarea name="notes" rows="3" placeholder="e.g., debuttoned"></textarea></label><br><br>
        <button type="submit">Create</button>
        <a href="/bits">Cancel</a>
      </form>
    </body></html>
    """
    return HTMLResponse(html)

@router.post("/new")
def create_bit(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    bit_number: str = Form(...),
    diameter_mm: str = Form(""),
    status: str = Form("NEW"),
    expected_life_m: str = Form(""),
    assumed_m_per_day: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    def pf(x: str) -> float | None:
        x = (x or "").strip()
        return float(x) if x not in ("", None) else None

    b = Bit(
        bit_number=bit_number.strip(),
        diameter_mm=pf(diameter_mm),
        status=BitStatus(status),
        expected_life_m=pf(expected_life_m),
        assumed_m_per_day=pf(assumed_m_per_day),
        notes=notes.strip(),
    )
    db.add(b)
    db.flush()
    write_log(db, actor=actor, entity="Bit", entity_id=b.id, action="CREATED", after_obj=b, summary=f"Bit {b.bit_number} created")
    db.commit()
    return RedirectResponse(url="/bits", status_code=303)

@router.get("/{bid}/edit", response_class=HTMLResponse)
def edit_bit_form(bid: int, ok: bool = Depends(require_writer), db: Session = Depends(get_db)):
    b = db.get(Bit, bid)
    if not b:
        raise HTTPException(status_code=404, detail="Not found")
    def sel(v: str) -> str:
        return "selected" if b.status.value == v else ""
    html = f"""
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>Edit Bit</h2>
      <form method="post" action="/bits/{b.id}/edit">
        <label>Serial number<br><input name="bit_number" value="{b.bit_number}" required></label><br><br>
        <label>Diameter (mm)<br><input name="diameter_mm" type="number" step="any" value="{b.diameter_mm if b.diameter_mm is not None else ''}"></label><br><br>
        <label>Status<br>
          <select name="status">
            <option value="NEW" {sel('NEW')}>New</option>
            <option value="USED" {sel('USED')}>Used</option>
            <option value="VERY_USED" {sel('VERY_USED')}>Very Used</option>
            <option value="NEEDS_RESHARPEN" {sel('NEEDS_RESHARPEN')}>Needs Resharpening</option>
            <option value="SHARPENED" {sel('SHARPENED')}>Sharpened</option>
            <option value="EOL" {sel('EOL')}>EOL</option>
          </select>
        </label><br><br>
        <label>Total meters (lifetime)<br><input name="total_meters" type="number" step="any" value="{b.total_meters}"></label><br><br>
        <label>Expected life (m)<br><input name="expected_life_m" type="number" step="any" value="{b.expected_life_m if b.expected_life_m is not None else ''}"></label><br><br>
        <label>Assumed meters/day<br><input name="assumed_m_per_day" type="number" step="any" value="{b.assumed_m_per_day if b.assumed_m_per_day is not None else ''}"></label><br><br>
        <label>Last used<br><input name="last_used" type="date" value="{b.last_used or ''}"></label><br><br>
        <label>Notes<br><textarea name="notes" rows="3">{b.notes or ''}</textarea></label><br><br>
        <button type="submit">Save</button>
        <a href="/bits">Cancel</a>
      </form>
      <hr>
      <form method="post" action="/bits/{b.id}/add_meters" style="margin-bottom:0.5rem;">
        <label>Add meters<br><input name="meters" type="number" step="any" required style="width:8em;"></label>
        <button type="submit">+ meters</button>
      </form>
      <div style="display:flex; gap:0.5rem;">
        <form method="post" action="/bits/{b.id}/mark/need-resharpen" onsubmit="return confirm('Mark as NEEDS RESHARPENING?');">
          <button type="submit">Needs resharpen</button>
        </form>
        <form method="post" action="/bits/{b.id}/mark/sharpened" onsubmit="return confirm('Mark as SHARPENED?');">
          <button type="submit">Sharpened</button>
        </form>
      </div>
    </body></html>
    """
    return HTMLResponse(html)

@router.post("/{bid}/edit")
def edit_bit(
    bid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    bit_number: str = Form(...),
    diameter_mm: str = Form(""),
    status: str = Form("NEW"),
    total_meters: str = Form("0"),
    expected_life_m: str = Form(""),
    assumed_m_per_day: str = Form(""),
    last_used: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    def pf(x: str) -> float | None:
        x = (x or "").strip()
        return float(x) if x not in ("", None) else None

    b = db.get(Bit, bid)
    if not b:
        return RedirectResponse(url="/bits", status_code=303)
    before = snapshot(b)
    b.bit_number = bit_number.strip()
    b.diameter_mm = pf(diameter_mm)
    b.status = BitStatus(status)
    b.total_meters = float(total_meters or 0)
    b.expected_life_m = pf(expected_life_m)
    b.assumed_m_per_day = pf(assumed_m_per_day)
    b.last_used = dt.date.fromisoformat(last_used) if last_used else None
    b.notes = notes.strip()

    # Light suggestion based on life usage (doesn't override resharpen/EOL choices)
    if b.expected_life_m and b.status in (BitStatus.NEW, BitStatus.USED, BitStatus.VERY_USED):
        frac = (b.total_meters or 0) / b.expected_life_m
        if frac >= 1.0 and b.status not in (BitStatus.EOL, BitStatus.NEEDS_RESHARPEN):
            b.status = BitStatus.VERY_USED
        elif frac >= LIFE_WARN_FRACTION and b.status == BitStatus.USED:
            b.status = BitStatus.VERY_USED

    write_log(db, actor=actor, entity="Bit", entity_id=b.id, action="UPDATED", before_obj=before, after_obj=b, summary=f"Bit {b.bit_number} updated")
    db.commit()
    return RedirectResponse(url="/bits", status_code=303)

@router.post("/{bid}/add_meters")
def add_meters(
    bid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    meters: float = Form(...),
    db: Session = Depends(get_db),
):
    b = db.get(Bit, bid)
    if not b:
        return RedirectResponse(url="/bits", status_code=303)
    before = snapshot(b)
    b.total_meters = float(b.total_meters or 0) + float(meters or 0)
    b.last_used = dt.date.today()

    # Gentle escalation unless user moved to resharpen/EOL paths
    if b.expected_life_m and b.status in (BitStatus.NEW, BitStatus.USED, BitStatus.VERY_USED):
        frac = (b.total_meters or 0) / b.expected_life_m
        if frac >= 1.0 and b.status != BitStatus.EOL:
            b.status = BitStatus.VERY_USED
        elif frac >= LIFE_WARN_FRACTION and b.status == BitStatus.USED:
            b.status = BitStatus.VERY_USED

    write_log(db, actor=actor, entity="Bit", entity_id=b.id, action="ADJUSTED", before_obj=before, after_obj=b, summary=f"Bit {b.bit_number} +{meters:g}m")
    db.commit()
    return RedirectResponse(url="/bits", status_code=303)

@router.post("/{bid}/mark/need-resharpen")
def mark_need_resharpen(
    bid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    db: Session = Depends(get_db),
):
    b = db.get(Bit, bid)
    if not b:
        return RedirectResponse(url="/bits", status_code=303)
    before = snapshot(b)
    b.status = BitStatus.NEEDS_RESHARPEN

    # Drop a general note to track work
    note = GeneralNote(
        title=f"Bit {b.bit_number} needs resharpening",
        content=f"Marked NEEDS_RESHARPEN on {dt.date.today().isoformat()} by {actor}.",
    )
    db.add(note)

    write_log(db, actor=actor, entity="Bit", entity_id=b.id, action="UPDATED", before_obj=before, after_obj=b,
              summary=f"Bit {b.bit_number} marked NEEDS_RESHARPEN")
    write_log(db, actor=actor, entity="GeneralNote", entity_id="n/a", action="CREATED", after_obj=note,
              summary=f"Note created for resharpening {b.bit_number}")
    db.commit()
    return RedirectResponse(url="/bits", status_code=303)

@router.post("/{bid}/mark/sharpened")
def mark_sharpened(
    bid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    db: Session = Depends(get_db),
):
    b = db.get(Bit, bid)
    if not b:
        return RedirectResponse(url="/bits", status_code=303)
    before = snapshot(b)
    b.status = BitStatus.SHARPENED
    b.prepared_by = actor or b.prepared_by
    b.prepared_at = dt.datetime.utcnow()

    # Drop a general note to record completion
    note = GeneralNote(
        title=f"Bit {b.bit_number} sharpened",
        content=f"Marked SHARPENED on {dt.date.today().isoformat()} by {actor}. "
                f"Lifetime meters retained at {b.total_meters:g} m.",
    )
    db.add(note)

    write_log(db, actor=actor, entity="Bit", entity_id=b.id, action="UPDATED", before_obj=before, after_obj=b,
              summary=f"Bit {b.bit_number} marked SHARPENED")
    write_log(db, actor=actor, entity="GeneralNote", entity_id="n/a", action="CREATED", after_obj=note,
              summary=f"Note created for sharpened {b.bit_number}")
    db.commit()
    return RedirectResponse(url="/bits", status_code=303)

@router.post("/{bid}/delete")
def delete_bit(bid: int, ok: bool = Depends(require_writer), actor: str = Depends(current_actor), db: Session = Depends(get_db)):
    b = db.get(Bit, bid)
    if not b:
        return RedirectResponse(url="/bits", status_code=303)
    # extra safety even though FK cascade is on
    from sqlalchemy import delete
    db.execute(delete(DailyUsage).where(DailyUsage.bit_id == bid))

    before = snapshot(b)
    num = b.bit_number
    db.delete(b)
    write_log(db, actor=actor, entity="Bit", entity_id=bid, action="DELETED", before_obj=before, after_obj={}, summary=f"Bit {num} deleted (and usage rows removed)")
    db.commit()
    return RedirectResponse(url="/bits", status_code=303)

@router.get("/export.csv")
def export_csv(db: Session = Depends(get_db)):
    bits = db.scalars(select(Bit).order_by(Bit.bit_number.asc())).all()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["serial_number", "diameter_mm", "status", "total_meters", "expected_life_m", "assumed_m_per_day", "last_used", "notes"])
    for b in bits:
        w.writerow([
            b.bit_number, b.diameter_mm or "", b.status.value,
            f"{b.total_meters:g}", b.expected_life_m or "", b.assumed_m_per_day or "",
            b.last_used or "", b.notes or ""
        ])
    buf.seek(0)
    headers = {"Content-Disposition": "attachment; filename=bits_export.csv"}
    return StreamingResponse(iter([buf.read()]), media_type="text/csv", headers=headers)

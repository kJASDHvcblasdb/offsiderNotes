from __future__ import annotations
import csv
import io
import datetime as dt

from fastapi import APIRouter, Depends, Form, HTTPException, Query
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy import select, desc
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Equipment, EquipmentCheck, EquipmentFault, EquipCheckStatus, Priority
from ..auth import require_writer, current_actor
from ..audit import write_log, snapshot

router = APIRouter(prefix="/equipment", tags=["equipment"])


def priority_badge(p: Priority) -> str:
    color = {Priority.HIGH: "#8b0000", Priority.MEDIUM: "#f9844a", Priority.LOW: "#2a9d8f"}[p]
    return f"<span style='color:#fff;background:{color};padding:2px 6px;border-radius:4px;'>{p.value.title()}</span>"


@router.get("", response_class=HTMLResponse)
def equipment_home(show: str = Query("open"), db: Session = Depends(get_db)):
    eq_list = db.scalars(select(Equipment).order_by(Equipment.name.asc())).all()
    fault_stmt = select(EquipmentFault).order_by(desc(EquipmentFault.reported_at))
    if show == "open":
        fault_stmt = fault_stmt.where(EquipmentFault.is_resolved == False)  # noqa: E712
    faults = db.scalars(fault_stmt).all()

    rows = []
    for e in eq_list:
        rows.append(
            f"<tr>"
            f"<td><a href='/equipment/{e.id}'>{e.name}</a><br><small>{e.serial or ''}</small></td>"
            f"<td>{'Yes' if e.active else 'No'}</td>"
            f"<td><small>{(e.notes or '').replace('<','&lt;')}</small></td>"
            f"<td><a href='/equipment/{e.id}'>View</a></td>"
            f"</tr>"
        )
    faults_rows = []
    for f in faults:
        faults_rows.append(
            f"<tr>"
            f"<td>{f.reported_at:%Y-%m-%d %H:%M}</td>"
            f"<td><a href='/equipment/{f.equipment_id}'>{f.equipment.name}</a></td>"
            f"<td>{priority_badge(f.priority)}</td>"
            f"<td><small>{(f.description or '').replace('<','&lt;')}</small></td>"
            f"<td>{'Yes' if f.is_resolved else 'No'}</td>"
            f"</tr>"
        )
    html = f"""
    <html><body style="font-family: system-ui; max-width: 1200px; margin: 2rem auto;">
      <h2>Equipment</h2>
      <div style="margin-bottom:1rem;">
        <a href="/equipment/new">+ New equipment</a> · <a href="/equipment/export.csv">Export CSV</a> ·
        <b>Faults filter:</b>
        <a href="/equipment?show=open">Open</a> |
        <a href="/equipment?show=all">All</a>
      </div>

      <h3>Faults ({'open' if show=='open' else 'all'})</h3>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>Reported</th><th>Equipment</th><th>Priority</th><th>Description</th><th>Resolved?</th></tr></thead>
        <tbody>{''.join(faults_rows) or "<tr><td colspan='5'>None 🎉</td></tr>"}</tbody>
      </table>

      <h3 style="margin-top:1.5rem;">All equipment</h3>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>Name / Serial</th><th>Active</th><th>Notes</th><th>Actions</th></tr></thead>
        <tbody>{''.join(rows) or "<tr><td colspan='4'>No equipment yet.</td></tr>"}</tbody>
      </table>

      <p style="margin-top:1rem;"><a href="/">Back</a></p>
    </body></html>
    """
    return HTMLResponse(html)

@router.get("/new", response_class=HTMLResponse)
def new_equipment_form(ok: bool = Depends(require_writer)):
    html = """
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>New Equipment</h2>
      <form method="post" action="/equipment/new">
        <label>Name<br><input name="name" required></label><br><br>
        <label>Serial (optional)<br><input name="serial"></label><br><br>
        <label>Active<br>
          <select name="active">
            <option value="1">Yes</option>
            <option value="0">No</option>
          </select>
        </label><br><br>
        <label>Notes<br><textarea name="notes" rows="4"></textarea></label><br><br>
        <button type="submit">Save</button>
        <a href="/equipment">Cancel</a>
      </form>
    </body></html>
    """
    return HTMLResponse(html)

@router.post("/new")
def create_equipment(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    name: str = Form(...),
    serial: str = Form(""),
    active: str = Form("1"),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    e = Equipment(name=name.strip(), serial=serial.strip() or None, active=(active == "1"), notes=notes.strip())
    db.add(e)
    db.flush()
    write_log(db, actor=actor, entity="Equipment", entity_id=e.id, action="CREATED", after_obj=e, summary=f"Equipment {e.name} created")
    db.commit()
    return RedirectResponse(url="/equipment", status_code=303)

@router.get("/{eid}", response_class=HTMLResponse)
def view_equipment(eid: int, db: Session = Depends(get_db)):
    e = db.get(Equipment, eid)
    if not e:
        raise HTTPException(status_code=404, detail="Not found")

    checks = db.scalars(select(EquipmentCheck).where(EquipmentCheck.equipment_id == e.id).order_by(desc(EquipmentCheck.when))).all()
    faults = db.scalars(select(EquipmentFault).where(EquipmentFault.equipment_id == e.id).order_by(desc(EquipmentFault.reported_at))).all()

    check_rows = []
    for c in checks:
        check_rows.append(
            f"<tr><td>{c.when:%Y-%m-%d %H:%M}</td><td>{c.status.value}</td><td><small>{(c.notes or '').replace('<','&lt;')}</small></td></tr>"
        )
    fault_rows = []
    for f in faults:
        fault_rows.append(
            f"<tr>"
            f"<td>{f.reported_at:%Y-%m-%d %H:%M}</td>"
            f"<td>{priority_badge(f.priority)}</td>"
            f"<td><small>{(f.description or '').replace('<','&lt;')}</small></td>"
            f"<td>{'Yes' if f.is_resolved else 'No'}</td>"
            f"<td><small>{(f.resolution_notes or '').replace('<','&lt;')}</small></td>"
            f"<td>"
            f"{'' if f.is_resolved else f'''<form method="post" action="/equipment/{e.id}/fault/{f.id}/resolve" style="display:inline;"><button type="submit">Resolve</button></form>'''}"
            f"</td>"
            f"</tr>"
        )

    html = f"""
    <html><body style="font-family: system-ui; max-width: 1000px; margin: 2rem auto;">
      <h2>{e.name}</h2>
      <p><b>Serial:</b> {e.serial or '-'} &nbsp; | &nbsp; <b>Active:</b> {'Yes' if e.active else 'No'}</p>
      <p><small>{(e.notes or '').replace('<','&lt;')}</small></p>

      <h3>Checks</h3>
      <form method="post" action="/equipment/{e.id}/check" style="margin-bottom:0.5rem;">
        <select name="status">
          <option value="OK">OK</option>
          <option value="ATTN">ATTN</option>
        </select>
        <input name="notes" placeholder="notes">
        <button type="submit">Add check</button>
      </form>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>When</th><th>Status</th><th>Notes</th></tr></thead>
        <tbody>{''.join(check_rows) or "<tr><td colspan='3'>No checks yet.</td></tr>"}</tbody>
      </table>

      <h3 style="margin-top:1.2rem;">Faults</h3>
      <form method="post" action="/equipment/{e.id}/fault" style="margin-bottom:0.5rem;">
        <select name="priority">
          <option value="HIGH">High</option>
          <option value="MEDIUM" selected>Medium</option>
          <option value="LOW">Low</option>
        </select>
        <input name="description" placeholder="description" required style="width:40%;">
        <button type="submit">Report fault</button>
      </form>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>Reported</th><th>Priority</th><th>Description</th><th>Resolved?</th><th>Resolution</th><th>Action</th></tr></thead>
        <tbody>{''.join(fault_rows) or "<tr><td colspan='6'>No faults yet.</td></tr>"}</tbody>
      </table>

      <p style="margin-top:1rem;"><a href="/equipment">Back</a></p>
    </body></html>
    """
    return HTMLResponse(html)

@router.post("/{eid}/check")
def add_check(
    eid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    status: str = Form("OK"),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    e = db.get(Equipment, eid)
    if not e:
        return RedirectResponse(url="/equipment", status_code=303)
    c = EquipmentCheck(equipment_id=e.id, status=EquipCheckStatus(status), notes=notes.strip())
    db.add(c)
    db.flush()
    write_log(db, actor=actor, entity="EquipmentCheck", entity_id=c.id, action="CREATED", after_obj=c, summary=f"Check {e.name} {c.status.value}")
    db.commit()
    return RedirectResponse(url=f"/equipment/{eid}", status_code=303)

@router.post("/{eid}/fault")
def add_fault(
    eid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    priority: str = Form("MEDIUM"),
    description: str = Form(...),
    db: Session = Depends(get_db),
):
    e = db.get(Equipment, eid)
    if not e:
        return RedirectResponse(url="/equipment", status_code=303)
    f = EquipmentFault(equipment_id=e.id, priority=Priority(priority), description=description.strip())
    db.add(f)
    db.flush()
    write_log(db, actor=actor, entity="EquipmentFault", entity_id=f.id, action="CREATED", after_obj=f, summary=f"Fault {e.name} {f.priority.value}")
    db.commit()
    return RedirectResponse(url=f"/equipment/{eid}", status_code=303)

@router.post("/{eid}/fault/{fid}/resolve")
def resolve_fault(
    eid: int,
    fid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    db: Session = Depends(get_db),
):
    f = db.get(EquipmentFault, fid)
    if not f or f.equipment_id != eid:
        return RedirectResponse(url=f"/equipment/{eid}", status_code=303)
    if f.is_resolved:
        return RedirectResponse(url=f"/equipment/{eid}", status_code=303)
    before = snapshot(f)
    f.is_resolved = True
    f.resolved_at = dt.datetime.utcnow()
    f.resolution_notes = (f.resolution_notes or "") + f"Resolved by {actor} on {dt.datetime.utcnow():%Y-%m-%d %H:%M}."
    write_log(db, actor=actor, entity="EquipmentFault", entity_id=f.id, action="UPDATED", before_obj=before, after_obj=f, summary=f"Fault resolved")
    db.commit()
    return RedirectResponse(url=f"/equipment/{eid}", status_code=303)

@router.get("/export.csv")
def export_equipment_csv(db: Session = Depends(get_db)):
    items = db.scalars(select(Equipment).order_by(Equipment.name.asc())).all()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["name", "serial", "active", "notes"])
    for e in items:
        w.writerow([e.name, e.serial or "", "yes" if e.active else "no", (e.notes or "").replace("\n", " ").strip()])
    buf.seek(0)
    headers = {"Content-Disposition": "attachment; filename=equipment_export.csv"}
    return StreamingResponse(iter([buf.read()]), media_type="text/csv", headers=headers)

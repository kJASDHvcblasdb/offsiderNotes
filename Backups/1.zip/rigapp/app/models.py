from __future__ import annotations
import datetime as dt
import enum
from typing import Optional, List

from sqlalchemy import (
    Integer, String, DateTime, Date, Boolean, Float, Text,
    ForeignKey, Enum, Index, UniqueConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base

# -------- Enums --------

class Priority(str, enum.Enum):
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"

class ShroudCondition(str, enum.Enum):
    NEW = "NEW"
    USED = "USED"

class EquipCheckStatus(str, enum.Enum):
    OK = "OK"
    ATTN = "ATTN"

class Shift(str, enum.Enum):
    AM = "AM"
    PM = "PM"

class BitStatus(str, enum.Enum):
    NEW = "NEW"
    USED = "USED"
    VERY_USED = "VERY_USED"
    NEEDS_RESHARPEN = "NEEDS_RESHARPEN"
    SHARPENED = "SHARPENED"
    EOL = "EOL"

# -------- Mixins / helpers --------

def utcnow() -> dt.datetime:
    return dt.datetime.utcnow()

class TimeStamped:
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

# -------- Core / Settings / Audit --------

class Settings(Base, TimeStamped):
    __tablename__ = "settings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    crew_pin_hash: Mapped[str] = mapped_column(String(200))
    timezone: Mapped[str] = mapped_column(String(64), default="Australia/Perth")
    reminder_horizon_days: Mapped[int] = mapped_column(Integer, default=14)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    when: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    actor: Mapped[str] = mapped_column(String(128))
    entity: Mapped[str] = mapped_column(String(64), index=True)
    entity_id: Mapped[str] = mapped_column(String(64), index=True)
    action: Mapped[str] = mapped_column(String(32))
    before_json: Mapped[str] = mapped_column(Text, default="")
    after_json: Mapped[str] = mapped_column(Text, default="")
    summary: Mapped[str] = mapped_column(Text, default="")
    __table_args__ = (Index("ix_audit_entity_when", "entity", "when"),)

# -------- Rig --------

class Rig(Base, TimeStamped):
    __tablename__ = "rigs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    identifier: Mapped[str] = mapped_column(String(64), unique=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

# -------- Stock & Restock --------

class StockItem(Base, TimeStamped):
    __tablename__ = "stock_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), index=True)
    unit: Mapped[str] = mapped_column(String(24), default="pcs")
    barcode: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    on_rig_qty: Mapped[float] = mapped_column(Float, default=0.0)
    min_qty: Mapped[float] = mapped_column(Float, default=0.0)
    buffer_qty: Mapped[float] = mapped_column(Float, default=0.0)
    priority: Mapped[Priority] = mapped_column(Enum(Priority), default=Priority.MEDIUM, index=True)
    critical: Mapped[bool] = mapped_column(Boolean, default=False)
    last_updated_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    category: Mapped[str] = mapped_column(String(64), default="consumable")
    notes: Mapped[str] = mapped_column(Text, default="")
    usage_per_day: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lead_time_days: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    restocks: Mapped[List["RestockItem"]] = relationship(
        back_populates="stock_item", cascade="all, delete-orphan"
    )

class RestockItem(Base, TimeStamped):
    __tablename__ = "restock_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stock_item_id: Mapped[int] = mapped_column(ForeignKey("stock_items.id"), index=True)
    requested_qty: Mapped[float] = mapped_column(Float)
    priority: Mapped[Priority] = mapped_column(Enum(Priority), default=Priority.MEDIUM)
    is_closed: Mapped[bool] = mapped_column(Boolean, default=False)
    needed_by_date: Mapped[Optional[dt.date]] = mapped_column(Date, nullable=True)
    closed_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    stock_item: Mapped[StockItem] = relationship(back_populates="restocks")

# -------- Bits / Shrouds / Usage --------

class Bit(Base, TimeStamped):
    __tablename__ = "bits"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bit_number: Mapped[str] = mapped_column(String(64), unique=True, index=True)  # client-critical serial
    diameter_mm: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    status: Mapped[BitStatus] = mapped_column(Enum(BitStatus), default=BitStatus.NEW, index=True)
    total_meters: Mapped[float] = mapped_column(Float, default=0.0)
    expected_life_m: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    # NEW: user-set projection input (no rolling window)
    assumed_m_per_day: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    last_used: Mapped[Optional[dt.date]] = mapped_column(Date, nullable=True)
    prepared_by: Mapped[str] = mapped_column(String(64), default="")
    prepared_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    notes: Mapped[str] = mapped_column(Text, default="")

    usages: Mapped[List["DailyUsage"]] = relationship(
        back_populates="bit",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

class Shroud(Base, TimeStamped):
    __tablename__ = "shrouds"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    size_mm: Mapped[float] = mapped_column(Float, index=True)
    condition: Mapped[ShroudCondition] = mapped_column(Enum(ShroudCondition), default=ShroudCondition.NEW, index=True)
    at_rig: Mapped[bool] = mapped_column(Boolean, default=True)
    barcode: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    usages: Mapped[List["DailyUsage"]] = relationship(back_populates="shroud")

class DailyUsage(Base):
    __tablename__ = "daily_usage"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    date: Mapped[dt.date] = mapped_column(Date, index=True)

    bit_id: Mapped[int] = mapped_column(ForeignKey("bits.id", ondelete="CASCADE"), index=True)
    shroud_id: Mapped[int] = mapped_column(ForeignKey("shrouds.id"), index=True)

    meters_drilled: Mapped[float] = mapped_column(Float, default=0.0)
    prepared_by: Mapped[str] = mapped_column(String(64), default="")
    notes: Mapped[str] = mapped_column(Text, default="")

    bit: Mapped[Bit] = relationship(back_populates="usages")
    shroud: Mapped[Shroud] = relationship(back_populates="usages")

    __table_args__ = (Index("ix_usage_date_bit_shroud", "date", "bit_id", "shroud_id"),)

# -------- Notes / Travel / Refuel / Prestart --------

class GeneralNote(Base, TimeStamped):
    __tablename__ = "general_notes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(200), index=True)
    content: Mapped[str] = mapped_column(Text, default="")

class TravelLog(Base):
    __tablename__ = "travel_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    when: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    location_text: Mapped[str] = mapped_column(String(200))
    lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")

class RefuelLog(Base):
    __tablename__ = "refuel_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    when: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    before_L: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    after_L: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    added_L: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    next_due_at: Mapped[Optional[dt.date]] = mapped_column(Date, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")

class Prestart(Base):
    __tablename__ = "prestarts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    date: Mapped[dt.date] = mapped_column(Date, index=True)
    shift: Mapped[Shift] = mapped_column(Enum(Shift), default=Shift.AM, index=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    created_by: Mapped[str] = mapped_column(String(64), default="")
    __table_args__ = (UniqueConstraint("date", "shift", name="uq_prestart_date_shift"),)

# -------- Equipment / Checks / Faults --------

class Equipment(Base, TimeStamped):
    __tablename__ = "equipment"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), index=True)
    serial: Mapped[Optional[str]] = mapped_column(String(120), nullable=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    checks: Mapped[List["EquipmentCheck"]] = relationship(
        back_populates="equipment", cascade="all, delete-orphan"
    )
    faults: Mapped[List["EquipmentFault"]] = relationship(
        back_populates="equipment", cascade="all, delete-orphan"
    )

class EquipmentCheck(Base):
    __tablename__ = "equipment_checks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    equipment_id: Mapped[int] = mapped_column(ForeignKey("equipment.id"), index=True)
    when: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    status: Mapped[EquipCheckStatus] = mapped_column(Enum(EquipCheckStatus), default=EquipCheckStatus.OK, index=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    equipment: Mapped[Equipment] = relationship(back_populates="checks")

class EquipmentFault(Base, TimeStamped):
    __tablename__ = "equipment_faults"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    equipment_id: Mapped[int] = mapped_column(ForeignKey("equipment.id"), index=True)
    reported_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    priority: Mapped[Priority] = mapped_column(Enum(Priority), default=Priority.MEDIUM, index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    is_resolved: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    resolved_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, nullable=True)
    resolution_notes: Mapped[str] = mapped_column(Text, default="")
    equipment: Mapped[Equipment] = relationship(back_populates="faults")

# -------- Handover --------

class Handover(Base, TimeStamped):
    __tablename__ = "handovers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    handed_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    from_person: Mapped[str] = mapped_column(String(64))
    to_person: Mapped[str] = mapped_column(String(64))
    notes: Mapped[str] = mapped_column(Text, default="")
    items: Mapped[List["HandoverItem"]] = relationship(
        back_populates="handover", cascade="all, delete-orphan"
    )

class HandoverItem(Base):
    __tablename__ = "handover_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    handover_id: Mapped[int] = mapped_column(ForeignKey("handovers.id"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    priority: Mapped[Priority] = mapped_column(Enum(Priority), default=Priority.MEDIUM)
    comment: Mapped[str] = mapped_column(Text, default="")
    handover: Mapped[Handover] = relationship(back_populates="items")

# -------- Threshold Rules --------

class ThresholdRule(Base, TimeStamped):
    __tablename__ = "threshold_rules"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stock_item_id: Mapped[int] = mapped_column(ForeignKey("stock_items.id"), index=True)
    min_qty_override: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    buffer_qty_override: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")

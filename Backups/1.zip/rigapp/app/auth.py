from __future__ import annotations
import hashlib
from typing import Optional
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from sqlalchemy import select

from .db import get_db
from .models import Settings

# Optional bcrypt support
try:
    import bcrypt  # type: ignore
    _HAS_BCRYPT = True
except Exception:  # pragma: no cover
    bcrypt = None
    _HAS_BCRYPT = False

router = APIRouter(prefix="/auth", tags=["auth"])

COOKIE_AUTH = "crew_auth"
COOKIE_ACTOR = "actor"

def _hash_pin_sha256(pin: str) -> str:
    return hashlib.sha256(pin.encode("utf-8")).hexdigest()

def _matches_hash(pin: str, stored: str) -> bool:
    """Accept SHA-256 (hex) OR bcrypt ($2b$...)"""
    pin_b = pin.encode("utf-8")
    # bcrypt?
    if stored.startswith("$2a$") or stored.startswith("$2b$") or stored.startswith("$2y$"):
        if not _HAS_BCRYPT:
            return False
        try:
            return bcrypt.checkpw(pin_b, stored.encode("utf-8"))
        except Exception:
            return False
    # otherwise expect sha256 hex
    return _hash_pin_sha256(pin) == stored

def _maybe_rehash_to_sha256(db: Session, s: Settings, pin: str) -> None:
    """If the stored hash is bcrypt and bcrypt matched, rehash to SHA-256 for consistency."""
    if s.crew_pin_hash and s.crew_pin_hash.startswith("$2") and _HAS_BCRYPT:
        s.crew_pin_hash = _hash_pin_sha256(pin)
        db.add(s)
        db.commit()

def _get_settings(db: Session) -> Settings:
    s = db.scalar(select(Settings).limit(1))
    if not s:
        raise HTTPException(status_code=500, detail="Settings not initialised. Run seed.")
    return s

def _redirect_to_pin(request: Request) -> HTTPException:
    path = request.url.path
    q = str(request.url.query or "")
    next_path = path + (("?" + q) if q else "")
    params = urlencode({"next": next_path})
    raise HTTPException(status_code=303, headers={"Location": f"/auth/pin?{params}"})

# ---------- dependencies ----------

def require_reader(request: Request) -> bool:
    if request.cookies.get(COOKIE_AUTH) == "1":
        return True
    raise _redirect_to_pin(request)

def require_writer(request: Request) -> bool:
    if request.cookies.get(COOKIE_AUTH) == "1":
        return True
    raise _redirect_to_pin(request)

def current_actor(request: Request) -> str:
    return request.cookies.get(COOKIE_ACTOR) or "Crew"

# ---------- routes ----------

@router.get("/pin", response_class=HTMLResponse)
def pin_form(next: Optional[str] = "/", error: Optional[str] = None):
    err_html = f"<p style='color:#8b0000;'>{error}</p>" if error else ""
    hint = "" if _HAS_BCRYPT else "<p class='muted' style='color:#555'>bcrypt not installed; only SHA-256 hashes will validate.</p>"
    html = f"""
    <html><body style="font-family: system-ui; max-width: 420px; margin: 2rem auto;">
      <h2>Enter PIN</h2>
      {err_html}
      {hint}
      <form method="post" action="/auth/pin">
        <input type="hidden" name="next" value="{next or '/'}"/>
        <label>PIN<br><input name="pin" type="password" required autofocus></label><br><br>
        <label>Your name (for audit)<br><input name="actor" placeholder="e.g., Cameron"></label><br><br>
        <button type="submit">Sign in</button>
        <a href="/">Cancel</a>
      </form>
      <p style="margin-top:1rem;"><a href="/auth/whoami">Who am I?</a></p>
    </body></html>
    """
    return HTMLResponse(html)

@router.post("/pin")
def pin_submit(
    request: Request,
    pin: str = Form(...),
    actor: str = Form("Crew"),
    next: str = Form("/"),
    db: Session = Depends(get_db),
):
    s = _get_settings(db)
    normalised_pin = (pin or "").strip()
    if not _matches_hash(normalised_pin, s.crew_pin_hash or ""):
        return RedirectResponse(url="/auth/pin?error=Invalid%20PIN", status_code=303)

    # Auto-migrate bcrypt -> sha256 (one-time, after successful check)
    _maybe_rehash_to_sha256(db, s, normalised_pin)

    if not next or next.startswith("/auth"):
        next = "/"

    resp = RedirectResponse(url=next, status_code=303)
    resp.set_cookie(COOKIE_AUTH, "1", path="/", httponly=True, samesite="lax")
    resp.set_cookie(COOKIE_ACTOR, (actor.strip() or "Crew"), path="/", httponly=False, samesite="lax")
    return resp

@router.post("/logout")
def logout():
    resp = RedirectResponse(url="/auth/pin", status_code=303)
    resp.delete_cookie(COOKIE_AUTH, path="/")
    resp.delete_cookie(COOKIE_ACTOR, path="/")
    return resp

@router.get("/whoami")
def whoami(request: Request):
    return {
        "auth_cookie": request.cookies.get(COOKIE_AUTH),
        "actor": request.cookies.get(COOKIE_ACTOR),
    }

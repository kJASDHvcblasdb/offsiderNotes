from __future__ import annotations

from html import escape
from urllib.parse import quote_plus, urlencode
from fastapi import APIRouter, Depends, Form, Query
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select, or_, and_

from ..db import get_db
from ..auth import require_reader, current_actor, current_rig_title
from ..models import StockItem
from ..audit import write_log
from ..ui import wrap_page

router = APIRouter(prefix="/stock", tags=["stock"])


def _laydown_predicate():
    """
    Heuristic for items stored in the laydown / sea containers based on location text.
    """
    return or_(
        StockItem.location.ilike("%container%"),
        StockItem.location.ilike("%sea container%"),
        StockItem.location.ilike("%laydown%"),
    )


@router.get("", response_class=HTMLResponse)
def stock_index(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
    db=Depends(get_db),
    q: str = Query("", description="Search query over name/location/unit"),
    area: str = Query("all", description="Filter area: all | rig | laydown"),
):
    # Base query
    stmt = select(StockItem)

    # Area filter
    if area.lower() == "laydown":
        stmt = stmt.where(_laydown_predicate())
    elif area.lower() == "rig":
        stmt = stmt.where(
            or_(
                StockItem.location.is_(None),
                and_(StockItem.location.is_not(None), ~_laydown_predicate()),
            )
        )

    # Search filter
    if q:
        like = f"%{q}%"
        stmt = stmt.where(
            or_(
                StockItem.name.ilike(like),
                StockItem.location.ilike(like),
                StockItem.unit.ilike(like),
            )
        )

    # Fetch
    stmt = stmt.order_by(StockItem.name)
    items = db.scalars(stmt).all()

    # Rank for sorting: 0 = critical, 1 = low, 2 = normal
    def _severity_rank(s: StockItem) -> int:
        qty = s.on_rig_qty or 0
        min_q = s.min_qty or 0
        buf_q = s.buffer_qty or 0
        if qty < min_q:
            return 0
        if qty < buf_q:
            return 1
        return 2

    items.sort(key=lambda s: (_severity_rank(s), (s.name or "").lower()))

    # Search + filter form with extra spacing/padding
    q_val = escape(q or "")
    area_val = (area or "all").lower()
    select_area = f"""
      <form method="get" action="/stock" class="form"
            style="margin:.25rem 0 1rem; display:flex; gap:.9rem; align-items:flex-end; flex-wrap:wrap;">
        <div style="display:flex; flex-direction:column; min-width:260px; padding:.25rem .5rem .5rem 0;">
          <label>Search</label>
          <input name="q" value="{q_val}" placeholder="name, location, unit">
        </div>
        <div style="display:flex; flex-direction:column; min-width:220px; padding:.25rem .5rem .5rem 0;">
          <label>Area</label>
          <select name="area">
            <option value="all" {"selected" if area_val=="all" else ""}>All</option>
            <option value="rig" {"selected" if area_val=="rig" else ""}>On-rig</option>
            <option value="laydown" {"selected" if area_val=="laydown" else ""}>Laydown (containers)</option>
          </select>
        </div>
        <div class="actions" style="padding:.25rem .5rem .5rem 0;">
          <button class="btn" type="submit">Filter</button>
          <a class="btn" href="/stock">Reset</a>
          <a class="btn" href="/stock/new">➕ Add stock item</a>
        </div>
      </form>
    """

    # URL-encoded params so +/- keeps current view
    q_url = quote_plus(q or "")
    area_url = quote_plus(area or "all")

    # Table rows with CRITICAL/LOW badges and quick +/- adjust
    rows = []
    for s in items:
        qty = s.on_rig_qty or 0
        min_q = s.min_qty or 0
        buf_q = s.buffer_qty or 0

        is_critical = qty < min_q
        is_low = (not is_critical) and (qty < buf_q)

        badge = ""
        tr_class = ""
        if is_critical:
            badge = " <span class='badge badge-critical'>CRITICAL</span>"
            tr_class = " class='row-critical'"
        elif is_low:
            badge = " <span class='badge badge-attention'>LOW</span>"
            tr_class = " class='row-attention'"

        adjust_action_base = f"/stock/{s.id}/adjust?q={q_url}&area={area_url}"
        adjust_html = f"""
          <div class="btn-group btn-group-inline">
            <form method="post" action="{adjust_action_base}" style="display:inline">
              <input type="hidden" name="delta" value="-5">
              <button class="btn btn-sm" type="submit">−5</button>
            </form>
            <form method="post" action="{adjust_action_base}" style="display:inline">
              <input type="hidden" name="delta" value="-1">
              <button class="btn btn-sm" type="submit">−1</button>
            </form>
            <form method="post" action="{adjust_action_base}" style="display:inline">
              <input type="hidden" name="delta" value="1">
              <button class="btn btn-sm" type="submit">+1</button>
            </form>
            <form method="post" action="{adjust_action_base}" style="display:inline">
              <input type="hidden" name="delta" value="5">
              <button class="btn btn-sm" type="submit">+5</button>
            </form>
          </div>
        """

        # One-click Restock (only when low/critical)
        restock_btn = ""
        if is_low or is_critical:
            target = (s.min_qty or 0) + (s.buffer_qty or 0)
            need = max(target - qty, 1)
            restock_url = f"/restock/new?stock_item_id={s.id}&qty={need}&unit={quote_plus(s.unit or 'ea')}"
            restock_btn = f"<a class='btn btn-sm' href='{restock_url}'>Restock +{need}</a> "

        actions_html = (
            f"{adjust_html}"
            f"{restock_btn}"
            f"<a class='btn' href='/stock/{s.id}/edit'>Edit</a> "
            f"<form method='post' action='/stock/{s.id}/delete' style='display:inline'>"
            f"<button class='btn' type='submit' onclick='return confirm(\"Delete {s.name}?\")'>Delete</button>"
            f"</form>"
        )

        rows.append(
            f"<tr{tr_class}>"
            f"<td>{s.name}{badge}</td>"
            f"<td>{s.on_rig_qty}</td><td>{s.min_qty}</td><td>{s.buffer_qty}</td>"
            f"<td>{s.unit}</td><td>{s.location or ''}</td>"
            f"<td>{actions_html}</td>"
            "</tr>"
        )

    table = (
        "<p class='muted'>No stock items match your filters.</p>"
        if not rows
        else (
            "<table><thead><tr>"
            "<th>Name</th><th>QTY</th><th>Min</th><th>Buffer</th><th>Unit</th><th>Location</th><th></th>"
            "</tr></thead>"
            f"<tbody>{''.join(rows)}</tbody></table>"
        )
    )

    body = select_area + table
    return wrap_page(title="Stock", body_html=body, actor=actor, rig_title=rig)


@router.get("/new", response_class=HTMLResponse)
def stock_new_form(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
):
    body = """
      <form method="post" action="/stock/new" class="form">
        <label>Name <input name="name" required></label>
        <label>QTY <input type="number" name="on_rig_qty" value="0"></label>
        <label>Min qty <input type="number" name="min_qty" value="0"></label>
        <label>Buffer qty <input type="number" name="buffer_qty" value="0"></label>
        <label>Unit <input name="unit" value="ea"></label>
        <label>Location <input name="location" placeholder="e.g. Rig locker / Sea container A / Laydown"></label>
        <div class="actions">
          <button class="btn" type="submit">Save</button>
          <a class="btn" href="/stock">Cancel</a>
        </div>
      </form>
    """
    return wrap_page(title="New Stock Item", body_html=body, actor=actor, rig_title=rig)


@router.post("/new")
def stock_new(
    actor: str = Depends(current_actor),
    name: str = Form(...),
    on_rig_qty: int = Form(0),
    min_qty: int = Form(0),
    buffer_qty: int = Form(0),
    unit: str = Form("ea"),
    location: str = Form(""),
    db=Depends(get_db),
):
    s = StockItem(
        name=name,
        on_rig_qty=on_rig_qty,
        min_qty=min_qty,
        buffer_qty=buffer_qty,
        unit=unit,
        location=(location or None),
    )
    db.add(s)
    db.commit()
    write_log(db, actor=actor or "crew", entity="stock", entity_id=s.id, action="create", summary=name)
    return RedirectResponse("/stock", status_code=303)


# --------- Quick adjust (+/-) -------------------------------------------------

@router.post("/{stock_id}/adjust")
def stock_adjust(
    stock_id: int,
    delta: int = Form(...),
    actor: str = Depends(current_actor),
    db=Depends(get_db),
    q: str = Query(""),
    area: str = Query("all"),
):
    s = db.get(StockItem, stock_id)
    if not s:
        return RedirectResponse("/stock", status_code=303)

    before = s.on_rig_qty or 0
    after = before + int(delta)
    if after < 0:
        after = 0  # guard against negative inventory for now

    s.on_rig_qty = after
    db.commit()
    write_log(
        db,
        actor=actor or "crew",
        entity="stock",
        entity_id=s.id,
        action="adjust",
        summary=f"{s.name}: {before} → {after} ({'+' if delta>=0 else ''}{delta})",
    )

    params = urlencode({"q": q or "", "area": area or "all"})
    return RedirectResponse(f"/stock?{params}", status_code=303)


# --------- Edit flow ----------------------------------------------------------

@router.get("/{stock_id}/edit", response_class=HTMLResponse)
def stock_edit_form(
    stock_id: int,
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    s = db.get(StockItem, stock_id)
    if not s:
        return RedirectResponse("/stock", status_code=303)

    body = f"""
      <form method="post" action="/stock/{s.id}/edit" class="form">
        <label>Name <input name="name" required value="{s.name}"></label>
        <label>QTY <input type="number" name="on_rig_qty" value="{s.on_rig_qty or 0}"></label>
        <label>Min qty <input type="number" name="min_qty" value="{s.min_qty or 0}"></label>
        <label>Buffer qty <input type="number" name="buffer_qty" value="{s.buffer_qty or 0}"></label>
        <label>Unit <input name="unit" value="{s.unit or 'ea'}"></label>
        <label>Location <input name="location" value="{s.location or ''}"></label>
        <div class="actions">
          <button class="btn" type="submit">Save changes</button>
          <a class="btn" href="/stock">Cancel</a>
        </div>
      </form>
    """
    return wrap_page(title=f"Edit: {s.name}", body_html=body, actor=actor, rig_title=rig)


@router.post("/{stock_id}/edit")
def stock_edit(
    stock_id: int,
    actor: str = Depends(current_actor),
    name: str = Form(...),
    on_rig_qty: int = Form(0),
    min_qty: int = Form(0),
    buffer_qty: int = Form(0),
    unit: str = Form("ea"),
    location: str = Form(""),
    db=Depends(get_db),
):
    s = db.get(StockItem, stock_id)
    if not s:
        return RedirectResponse("/stock", status_code=303)

    before = f"{s.name} [{s.on_rig_qty}/{s.min_qty}/{s.buffer_qty} {s.unit}]"
    s.name = name
    s.on_rig_qty = on_rig_qty
    s.min_qty = min_qty
    s.buffer_qty = buffer_qty
    s.unit = unit
    s.location = (location or None)

    db.commit()
    after = f"{s.name} [{s.on_rig_qty}/{s.min_qty}/{s.buffer_qty} {s.unit}]"
    write_log(
        db,
        actor=actor or "crew",
        entity="stock",
        entity_id=s.id,
        action="update",
        summary=f"{before} → {after}",
    )
    return RedirectResponse("/stock", status_code=303)


@router.post("/{stock_id}/delete")
def stock_delete(
    stock_id: int,
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    s = db.get(StockItem, stock_id)
    if s:
        name = s.name
        db.delete(s)
        db.commit()
        write_log(db, actor=actor or "crew", entity="stock", entity_id=stock_id, action="delete", summary=name or "")
    return RedirectResponse("/stock", status_code=303)

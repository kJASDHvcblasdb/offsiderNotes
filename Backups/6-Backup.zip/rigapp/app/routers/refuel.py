from __future__ import annotations

from fastapi import APIRouter, Depends, Form
from fastapi.responses import RedirectResponse
from sqlalchemy import select

from ..db import get_db
from ..models import RefuelLog
from ..auth import require_reader, current_actor, current_rig_title
from ..audit import write_log
from ..ui import wrap_page

router = APIRouter(prefix="/refuel", tags=["refuel"])

@router.get("")
def refuel_index(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    rows = []
    for r in db.scalars(select(RefuelLog).order_by(RefuelLog.id.desc())).all():
        rows.append(
            f"<tr><td>{r.id}</td><td>{r.fuel_type or ''}</td><td>{r.amount_litres or ''}</td>"
            f"<td>{r.before_after_note or ''}</td><td>{r.notes or ''}</td></tr>"
        )
    table = "<p class='muted'>No refuels yet.</p>" if not rows else (
        "<table><thead><tr><th>ID</th><th>Fuel</th><th>Litres</th><th>When</th><th>Notes</th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table>"
    )
    body = f"""
      <p><a class="btn" href="/refuel/new">➕ New refuel</a></p>
      {table}
    """
    return wrap_page(title="Refuel", body_html=body, actor=actor, rig_title=rig)

@router.get("/new")
def refuel_new_form(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
):
    body = """
      <form method="post" action="/refuel/new" class="form">
        <label>Fuel type <input name="fuel_type" placeholder="Diesel"></label>
        <label>Amount (litres) <input type="number" step="0.01" name="amount_litres" required></label>
        <label>When note <input name="before_after_note" placeholder="Before/After service"></label>
        <label>Notes <textarea name="notes" rows="3"></textarea></label>
        <div class="actions">
          <button class="btn" type="submit">Save</button>
          <a class="btn" href="/refuel">Cancel</a>
        </div>
      </form>
    """
    return wrap_page(title="New Refuel", body_html=body, actor=actor, rig_title=rig)

@router.post("/new")
def refuel_new(
    actor: str = Depends(current_actor),
    fuel_type: str = Form(""),
    amount_litres: float = Form(...),
    before_after_note: str = Form(""),
    notes: str = Form(""),
    db=Depends(get_db),
):
    r = RefuelLog(
        fuel_type=fuel_type or None,
        amount_litres=amount_litres,
        before_after_note=before_after_note or None,
        notes=notes or None,
    )
    db.add(r)
    db.commit()
    write_log(db, actor=actor or "crew", entity="refuel", entity_id=r.id, action="create", summary=f"{amount_litres}L {fuel_type or ''}")
    return RedirectResponse("/refuel", status_code=303)

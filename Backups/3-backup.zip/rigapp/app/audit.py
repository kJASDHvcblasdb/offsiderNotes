from __future__ import annotations
import json
import datetime as dt
from typing import Any, Dict, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.inspection import inspect as sa_inspect

from .models import AuditLog

# -------- helpers --------

def _json_dumps(obj: Any) -> str:
    # robust JSON dumping for datetimes/decimals/etc.
    return json.dumps(obj, default=str, ensure_ascii=False)

def snapshot(model_obj: Any) -> Dict[str, Any]:
    """
    Return a plain dict of column -> value for a SQLAlchemy model instance.
    If obj is None, returns {}.
    """
    if model_obj is None:
        return {}
    try:
        mapper = sa_inspect(model_obj).mapper
        data: Dict[str, Any] = {}
        for col in mapper.columns:
            data[col.key] = getattr(model_obj, col.key)
        return data
    except Exception:
        # fallback: best-effort
        out = {}
        for k, v in getattr(model_obj, "__dict__", {}).items():
            if not k.startswith("_"):
                out[k] = v
        return out

# -------- main API --------

def write_log(
    db: Session,
    *,
    actor: str,
    entity: str,
    entity_id: Any,
    action: str,
    before_obj: Optional[Any] = None,
    after_obj: Optional[Any] = None,
    summary: str = "",
) -> AuditLog:
    """
    Persist an audit row with JSON snapshots. Call db.commit() outside if batching.
    """
    before_json = _json_dumps(snapshot(before_obj)) if before_obj is not None else ""
    after_json = _json_dumps(snapshot(after_obj)) if after_obj is not None else ""
    row = AuditLog(
        actor=actor or "Crew",
        entity=str(entity),
        entity_id=str(entity_id),
        action=str(action),
        before_json=before_json,
        after_json=after_json,
        summary=summary or "",
    )
    db.add(row)
    # don't commit here; let caller control txn to keep it atomic with their changes
    return row

def recent_logs(db: Session, limit: int = 20) -> list[AuditLog]:
    """
    Return latest N audit rows (newest first).
    """
    return db.scalars(
        select(AuditLog).order_by(AuditLog.when.desc()).limit(max(1, int(limit)))
    ).all()

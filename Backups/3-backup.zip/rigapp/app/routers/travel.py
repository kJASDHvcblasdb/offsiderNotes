from __future__ import annotations
from ..ui import page_auto
import csv
import io
import datetime as dt

from ..ui import page_auto
from fastapi import APIRouter, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import select, desc

from ..db import get_db
from ..models import TravelLog
from ..auth import require_writer, current_actor
from ..audit import write_log

router = APIRouter(prefix="/travel", tags=["travel"])

@router.get("", response_class=HTMLResponse)
def list_travel(db: Session = Depends(get_db)):
    rows = db.scalars(select(TravelLog).order_by(desc(TravelLog.when))).all()
    tr = []
    for r in rows:
        loc = (r.location_text or "").replace("<", "&lt;")
        notes = (r.notes or "").replace("<", "&lt;")
        tr.append(f"<tr><td>{r.when:%Y-%m-%d %H:%M}</td><td>{loc}</td><td>{r.lat or ''}</td><td>{r.lon or ''}</td><td><small>{notes}</small></td></tr>")
    html = f"""
    <html><body style="font-family: system-ui; max-width: 1100px; margin: 2rem auto;">
      <h2>Travel Log</h2>
      <div style="margin-bottom:1rem;">
        <a href="/travel/new">+ New entry</a> · <a href="/travel/export.csv">Export CSV</a>
      </div>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>When</th><th>Location</th><th>Lat</th><th>Lon</th><th>Notes</th></tr></thead>
        <tbody>{''.join(tr) or "<tr><td colspan='5'>No travel logged.</td></tr>"}</tbody>
      </table>
      <p style="margin-top:1rem;"><a href="/">Back</a></p>
    </body></html>
    """
    return page_auto(html)

@router.get("/new", response_class=HTMLResponse)
def new_travel_form(ok: bool = Depends(require_writer)):
    now = dt.datetime.now().isoformat(timespec="minutes")
    html = f"""
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>New Travel Entry</h2>
      <form method="post" action="/travel/new">
        <label>When<br><input name="when" type="datetime-local" value="{now}" required></label><br><br>
        <label>Location text<br><input name="location_text" placeholder="e.g., Rig to depot" required></label><br><br>
        <label>Latitude (optional)<br><input name="lat" type="number" step="any"></label><br><br>
        <label>Longitude (optional)<br><input name="lon" type="number" step="any"></label><br><br>
        <label>Notes<br><textarea name="notes" rows="3"></textarea></label><br><br>
        <button type="submit">Save</button>
        <a href="/travel">Cancel</a>
      </form>
    </body></html>
    """
    return page_auto(html)

@router.post("/new")
def create_travel(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    when: str = Form(...),
    location_text: str = Form(...),
    lat: str = Form(""),
    lon: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    row = TravelLog(
        when=dt.datetime.fromisoformat(when),
        location_text=location_text.strip(),
        lat=(float(lat) if lat.strip() else None),
        lon=(float(lon) if lon.strip() else None),
        notes=notes.strip(),
    )
    db.add(row)
    db.flush()
    write_log(db, actor=actor, entity="TravelLog", entity_id=row.id, action="CREATED", after_obj=row, summary=f"Travel: {row.location_text}")
    db.commit()
    return RedirectResponse(url="/travel", status_code=303)

@router.get("/export.csv")
def export_travel_csv(db: Session = Depends(get_db)):
    rows = db.scalars(select(TravelLog).order_by(TravelLog.when.asc())).all()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["when", "location", "lat", "lon", "notes"])
    for r in rows:
        w.writerow([r.when.isoformat(), r.location_text or "", r.lat or "", r.lon or "", (r.notes or "").replace("\n"," ").strip()])
    buf.seek(0)
    headers = {"Content-Disposition": "attachment; filename=travel_export.csv"}
    return StreamingResponse(iter([buf.read()]), media_type="text/csv", headers=headers)

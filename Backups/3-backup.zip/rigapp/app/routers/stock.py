from __future__ import annotations
from ..ui import page_auto
import io
import csv as csv_module
import datetime as dt
from ..ui import page_auto
from typing import Optional

from fastapi import APIRouter, Depends, Form, HTTPException, Query
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import StockItem
from ..auth import require_reader, require_writer, current_actor
from ..audit import write_log, snapshot

router = APIRouter(prefix="/stock", tags=["stock"])


# -----------------------------
# Helpers
# -----------------------------

def _prio_badge(s: StockItem) -> str:
    if s.critical:
        color = "#8b0000"
        label = "CRITICAL"
    else:
        label = (s.priority or "").upper()
        color = {"HIGH": "#d97706", "MEDIUM": "#1f6feb", "LOW": "#2a9d8f", "": "#777"}.get(label, "#777")
    return f"<span style='color:#fff;background:{color};padding:2px 6px;border-radius:4px;'>{label or '-'}</span>"

def _estimate_days_to_min(s: StockItem) -> Optional[int]:
    """Days until hitting (min + buffer). Returns None if not enough info."""
    if (s.usage_per_day or 0) <= 0:
        return None
    target = (s.min_qty or 0) + (s.buffer_qty or 0)
    if s.on_rig_qty is None:
        return None
    delta = s.on_rig_qty - target
    # if already below, 0
    if delta <= 0:
        return 0
    return int(delta // max(s.usage_per_day, 0.00001))

def _restock_by_date(s: StockItem) -> Optional[str]:
    """If we have lead_time_days + usage_per_day, suggest target date to place order."""
    days = _estimate_days_to_min(s)
    if days is None or s.lead_time_days is None:
        return None
    target_days = days - s.lead_time_days
    date = dt.date.today() + dt.timedelta(days=max(target_days, 0))
    return date.isoformat()

def _archived(s: StockItem) -> bool:
    return "[ARCHIVED]" in (s.notes or "")


# -----------------------------
# List / Home
# -----------------------------

@router.get("", response_class=HTMLResponse)
def stock_home(ok: bool = Depends(require_reader), db: Session = Depends(get_db)):
    items = db.scalars(select(StockItem).order_by(StockItem.name.asc())).all()
    rows = []
    for s in items:
        est = _estimate_days_to_min(s)
        due = _restock_by_date(s)
        est_txt = "-" if est is None else (f"{est}d" if est > 0 else "now")
        due_txt = due or "-"
        prio = _prio_badge(s)
        style = " style='color:#777;'" if _archived(s) else ""
        notes = (s.notes or "").replace("<", "&lt;")
        rows.append(
            f"<tr{style}>"
            f"<td>{s.name}<br><small>{s.unit or ''}</small></td>"
            f"<td class='right'>{s.on_rig_qty:g}</td>"
            f"<td class='right'>{s.min_qty:g} + {s.buffer_qty:g}</td>"
            f"<td>{prio}</td>"
            f"<td class='center'>{est_txt}</td>"
            f"<td class='center'>{due_txt}</td>"
            f"<td><small>{notes}</small></td>"
            f"<td>"
            f"<a href='/stock/{s.id}/edit'>Edit</a>"
            f" · <form class='noprint' method='post' action='/stock/{s.id}/delete' style='display:inline;' onsubmit=\"return confirm('Delete item? If referenced, it will be archived instead.');\"><button type='submit'>Delete</button></form>"
            f"</td>"
            f"</tr>"
        )

    html = f"""
    <html><body class="container">
      <h2>Stock</h2>
      <div class="quick">
        <a href="/stock/new">+ New item</a> ·
        <a href="/stock/search">Search</a> ·
        <a href="/stock/import">Import CSV</a> ·
        <a href="/stock/export.csv">Export CSV</a> ·
        <a href="#" onclick="window.print()">Print</a>
      </div>
      <table>
        <thead><tr>
          <th>Item</th><th class='right'>On rig</th><th class='right'>Min + Buffer</th>
          <th>Priority</th><th class='center'>Est. to min</th><th class='center'>Order by</th><th>Notes</th><th>Actions</th>
        </tr></thead>
        <tbody>
          {''.join(rows) or "<tr><td colspan='8'>No stock yet.</td></tr>"}
        </tbody>
      </table>
      <p style="margin-top:1rem;"><a href="/">Back</a></p>
    </body></html>
    """
    return page_auto(html)


# -----------------------------
# Create / Edit
# -----------------------------

@router.get("/new", response_class=HTMLResponse)
def stock_new_form(ok: bool = Depends(require_writer)):
    html = """
    <html><body class="container">
      <h2>New Stock Item</h2>
      <form method="post" action="/stock/new">
        <div class="row">
          <div class="col">
            <label>Name<br><input name="name" required></label>
          </div>
          <div class="col">
            <label>Unit<br><input name="unit" placeholder="e.g., L, pcs"></label>
          </div>
        </div>
        <div class="row">
          <div class="col"><label>On rig qty<br><input name="on_rig_qty" type="number" step="0.01" value="0"></label></div>
          <div class="col"><label>Min qty<br><input name="min_qty" type="number" step="0.01" value="0"></label></div>
          <div class="col"><label>Buffer qty<br><input name="buffer_qty" type="number" step="0.01" value="0"></label></div>
        </div>
        <div class="row">
          <div class="col"><label>Usage / day<br><input name="usage_per_day" type="number" step="0.01" placeholder="optional"></label></div>
          <div class="col"><label>Lead time (days)<br><input name="lead_time_days" type="number" step="1" placeholder="optional"></label></div>
        </div>
        <div class="row">
          <div class="col">
            <label>Priority<br>
              <select name="priority">
                <option value="">(none)</option>
                <option value="LOW">LOW</option>
                <option value="MEDIUM">MEDIUM</option>
                <option value="HIGH">HIGH</option>
              </select>
            </label>
          </div>
          <div class="col">
            <label>Critical?<br>
              <select name="critical">
                <option value="0">No</option>
                <option value="1">Yes</option>
              </select>
            </label>
          </div>
        </div>
        <label>Notes<br><textarea name="notes" rows="3"></textarea></label><br><br>
        <button type="submit">Save</button> <a href="/stock">Cancel</a>
      </form>
    </body></html>
    """
    return page_auto(html)


@router.post("/new")
def stock_new(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    name: str = Form(...),
    unit: str = Form(""),
    on_rig_qty: float = Form(0.0),
    min_qty: float = Form(0.0),
    buffer_qty: float = Form(0.0),
    usage_per_day: Optional[float] = Form(None),
    lead_time_days: Optional[int] = Form(None),
    priority: str = Form(""),
    critical: str = Form("0"),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    s = StockItem(
        name=name.strip(),
        unit=unit.strip() or None,
        on_rig_qty=on_rig_qty or 0,
        min_qty=min_qty or 0,
        buffer_qty=buffer_qty or 0,
        usage_per_day=usage_per_day,
        lead_time_days=lead_time_days,
        priority=(priority or "").strip(),   # NOTE: keep non-null
        critical=(critical == "1"),
        notes=notes.strip() or None,
    )
    db.add(s)
    db.flush()
    write_log(db, actor=actor, entity="StockItem", entity_id=s.id, action="CREATED", after_obj=s, summary=f"Created stock '{s.name}'")
    db.commit()
    return RedirectResponse(url="/stock", status_code=303)


@router.get("/{sid}/edit", response_class=HTMLResponse)
def stock_edit_form(sid: int, ok: bool = Depends(require_writer), db: Session = Depends(get_db)):
    s = db.get(StockItem, sid)
    if not s:
        raise HTTPException(status_code=404, detail="Not found")
    notes = (s.notes or "")
    html = f"""
    <html><body class="container">
      <h2>Edit Stock Item</h2>
      <form method="post" action="/stock/{s.id}/edit">
        <div class="row">
          <div class="col"><label>Name<br><input name="name" value="{s.name}" required></label></div>
          <div class="col"><label>Unit<br><input name="unit" value="{s.unit or ''}"></label></div>
        </div>
        <div class="row">
          <div class="col"><label>On rig qty<br><input name="on_rig_qty" type="number" step="0.01" value="{s.on_rig_qty:g}"></label></div>
          <div class="col"><label>Min qty<br><input name="min_qty" type="number" step="0.01" value="{s.min_qty:g}"></label></div>
          <div class="col"><label>Buffer qty<br><input name="buffer_qty" type="number" step="0.01" value="{s.buffer_qty:g}"></label></div>
        </div>
        <div class="row">
          <div class="col"><label>Usage / day<br><input name="usage_per_day" type="number" step="0.01" value="{s.usage_per_day if s.usage_per_day is not None else ''}"></label></div>
          <div class="col"><label>Lead time (days)<br><input name="lead_time_days" type="number" step="1" value="{s.lead_time_days if s.lead_time_days is not None else ''}"></label></div>
        </div>
        <div class="row">
          <div class="col">
            <label>Priority<br>
              <select name="priority">
                <option value="" {"selected" if (s.priority or "")=="" else ""}>(none)</option>
                <option value="LOW" {"selected" if (s.priority or "").upper()=="LOW" else ""}>LOW</option>
                <option value="MEDIUM" {"selected" if (s.priority or "").upper()=="MEDIUM" else ""}>MEDIUM</option>
                <option value="HIGH" {"selected" if (s.priority or "").upper()=="HIGH" else ""}>HIGH</option>
              </select>
            </label>
          </div>
          <div class="col">
            <label>Critical?<br>
              <select name="critical">
                <option value="0" {"selected" if not s.critical else ""}>No</option>
                <option value="1" {"selected" if s.critical else ""}>Yes</option>
              </select>
            </label>
          </div>
        </div>
        <label>Notes<br><textarea name="notes" rows="3">{notes}</textarea></label><br><br>
        <button type="submit">Save</button> <a href="/stock">Cancel</a>
      </form>
    </body></html>
    """
    return page_auto(html)


@router.post("/{sid}/edit")
def stock_edit(
    sid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    name: str = Form(...),
    unit: str = Form(""),
    on_rig_qty: float = Form(0.0),
    min_qty: float = Form(0.0),
    buffer_qty: float = Form(0.0),
    usage_per_day: Optional[float] = Form(None),
    lead_time_days: Optional[int] = Form(None),
    priority: str = Form(""),
    critical: str = Form("0"),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    s = db.get(StockItem, sid)
    if not s:
        raise HTTPException(status_code=404, detail="Not found")

    before = snapshot(s)
    s.name = name.strip()
    s.unit = unit.strip() or None
    s.on_rig_qty = on_rig_qty or 0
    s.min_qty = min_qty or 0
    s.buffer_qty = buffer_qty or 0
    s.usage_per_day = usage_per_day
    s.lead_time_days = lead_time_days
    s.priority = (priority or "").strip()     # keep non-null
    s.critical = (critical == "1")
    s.notes = notes.strip() or None
    write_log(db, actor=actor, entity="StockItem", entity_id=s.id, action="UPDATED", before_obj=before, after_obj=s, summary=f"Updated stock '{s.name}'")
    db.commit()
    return RedirectResponse(url="/stock", status_code=303)


# -----------------------------
# Adjust quantity (delta)
# -----------------------------

@router.post("/{sid}/adjust")
def stock_adjust(
    sid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    delta: float = Form(...),
    reason: str = Form(""),
    db: Session = Depends(get_db),
):
    s = db.get(StockItem, sid)
    if not s:
        raise HTTPException(status_code=404, detail="Not found")

    before = snapshot(s)
    s.on_rig_qty = (s.on_rig_qty or 0) + delta
    write_log(
        db,
        actor=actor,
        entity="StockItem",
        entity_id=s.id,
        action="ADJUSTED",
        before_obj=before,
        after_obj=s,
        summary=f"Adjusted '{s.name}' {before.get('on_rig_qty',0)} -> {s.on_rig_qty} ({'+' if delta>=0 else ''}{delta}) - {reason or 'n/a'}",
    )
    db.commit()
    return RedirectResponse(url="/stock", status_code=303)


# -----------------------------
# Delete (with graceful archive fallback)
# -----------------------------

@router.post("/{sid}/delete")
def stock_delete(
    sid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    db: Session = Depends(get_db),
):
    s = db.get(StockItem, sid)
    if not s:
        return RedirectResponse(url="/stock", status_code=303)

    before = snapshot(s)
    try:
        db.delete(s)
        db.flush()
        write_log(
            db,
            actor=actor,
            entity="StockItem",
            entity_id=sid,
            action="DELETED",
            before_obj=before,
            after_obj=None,
            summary=f"Deleted stock '{before.get('name','item')}'",
        )
        db.commit()
        return RedirectResponse(url="/stock", status_code=303)

    except IntegrityError:
        # Item is still referenced (restock/usage/etc.) — archive instead of deleting.
        db.rollback()
        s.on_rig_qty = 0
        s.critical = False
        # IMPORTANT: priority column is NOT NULL in your DB — keep non-null
        s.priority = s.priority or ""   # retain existing if set, else empty string (non-null)
        note = (s.notes or "")
        if "[ARCHIVED]" not in note:
            s.notes = (note + " [ARCHIVED]").strip()
        write_log(
            db,
            actor=actor,
            entity="StockItem",
            entity_id=s.id,
            action="UPDATED",
            before_obj=before,
            after_obj=s,
            summary=f"Archive fallback for '{s.name}' (FK in use)",
        )
        db.commit()
        return RedirectResponse(url="/stock", status_code=303)


# -----------------------------
# Search
# -----------------------------

@router.get("/search", response_class=HTMLResponse)
def stock_search(q: str = Query(""), db: Session = Depends(get_db)):
    like = f"%{q.strip()}%"
    items = db.scalars(select(StockItem).where(StockItem.name.ilike(like)).order_by(StockItem.name.asc())).all()
    rows = []
    for s in items:
        prio = _prio_badge(s)
        style = " style='color:#777;'" if _archived(s) else ""
        rows.append(
            f"<tr{style}>"
            f"<td>{s.name}<br><small>{s.unit or ''}</small></td>"
            f"<td class='right'>{s.on_rig_qty:g}</td>"
            f"<td class='right'>{s.min_qty:g} + {s.buffer_qty:g}</td>"
            f"<td>{prio}</td>"
            f"<td><small>{(s.notes or '').replace('<','&lt;')}</small></td>"
            f"<td><a href='/stock/{s.id}/edit'>Edit</a></td>"
            f"</tr>"
        )
    html = f"""
    <html><body class="container">
      <h2>Stock Search</h2>
      <form method="get" action="/stock/search" style="margin-bottom:1rem;">
        <input name="q" value="{q}" placeholder="name contains..." autofocus style="max-width:360px;">
        <button type="submit">Search</button>
        <a href="/stock" style="margin-left:1rem;">Back</a>
      </form>
      <table>
        <thead><tr><th>Item</th><th class='right'>On rig</th><th class='right'>Min+Buffer</th><th>Priority</th><th>Notes</th><th>Actions</th></tr></thead>
        <tbody>{''.join(rows) or "<tr><td colspan='6'>No matches.</td></tr>"}</tbody>
      </table>
    </body></html>
    """
    return page_auto(html)


# -----------------------------
# Export CSV
# -----------------------------

@router.get("/export.csv")
def export_stock_csv(db: Session = Depends(get_db)):
    items = db.scalars(select(StockItem).order_by(StockItem.name.asc())).all()
    buf = io.StringIO()
    w = csv_module.writer(buf)
    w.writerow([
        "name","unit","on_rig_qty","min_qty","buffer_qty",
        "notes","priority","critical","usage_per_day","lead_time_days","archived"
    ])
    for s in items:
        w.writerow([
            s.name, s.unit or "", s.on_rig_qty or 0, s.min_qty or 0, s.buffer_qty or 0,
            (s.notes or "").replace("\n"," ").strip(), (s.priority or ""),
            "yes" if s.critical else "no",
            s.usage_per_day if s.usage_per_day is not None else "",
            s.lead_time_days if s.lead_time_days is not None else "",
            "yes" if _archived(s) else "no",
        ])
    buf.seek(0)
    headers = {"Content-Disposition": "attachment; filename=stock_export.csv"}
    return StreamingResponse(iter([buf.read()]), media_type="text/csv", headers=headers)


# -----------------------------
# Import CSV (textarea)
# -----------------------------

@router.get("/import", response_class=HTMLResponse)
def import_stock_form(ok: bool = Depends(require_writer)):
    sample = "name,unit,on_rig_qty,min_qty,buffer_qty,notes,priority,critical,usage_per_day,lead_time_days\n" \
             "Hammer Oil,L,8,4,2,Added today,HIGH,yes,1.0,3\n"
    html = f"""
    <html><body class="container">
      <h2>Import Stock CSV</h2>
      <p>Paste CSV with header:</p>
      <pre>name,unit,on_rig_qty,min_qty,buffer_qty,notes,priority,critical,usage_per_day,lead_time_days</pre>
      <form method="post" action="/stock/import">
        <textarea name="csv" rows="12" style="width:100%;" placeholder="Paste here...">{sample}</textarea><br><br>
        <button type="submit">Import</button> <a href="/stock">Cancel</a>
      </form>
    </body></html>
    """
    return page_auto(html)


@router.post("/import")
def import_stock(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    csv: str = Form(...),
    db: Session = Depends(get_db),
):
    f = io.StringIO(csv.strip())
    reader = csv_module.DictReader(f)
    for row in reader:
        name = (row.get("name") or "").strip()
        if not name:
            continue
        s = db.scalar(select(StockItem).where(StockItem.name == name))
        fields = dict(
            unit=(row.get("unit") or "").strip() or None,
            on_rig_qty=float(row.get("on_rig_qty") or 0),
            min_qty=float(row.get("min_qty") or 0),
            buffer_qty=float(row.get("buffer_qty") or 0),
            notes=(row.get("notes") or "").strip() or None,
            priority=(row.get("priority") or "").strip(),  # keep non-null
            critical=((row.get("critical") or "").strip().lower() in ("yes","true","1")),
            usage_per_day=(float(row.get("usage_per_day")) if (row.get("usage_per_day") or "").strip() else None),
            lead_time_days=(int(float(row.get("lead_time_days"))) if (row.get("lead_time_days") or "").strip() else None),
        )
        if s:
            before = snapshot(s)
            for k, v in fields.items():
                setattr(s, k, v)
            write_log(db, actor=actor, entity="StockItem", entity_id=s.id, action="UPDATED", before_obj=before, after_obj=s, summary=f"Import update '{s.name}'")
        else:
            s = StockItem(name=name, **fields)
            db.add(s)
            db.flush()
            write_log(db, actor=actor, entity="StockItem", entity_id=s.id, action="CREATED", after_obj=s, summary=f"Import create '{s.name}'")
    db.commit()
    return RedirectResponse(url="/stock", status_code=303)

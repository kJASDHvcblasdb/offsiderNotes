from __future__ import annotations
from ..ui import page_auto
import csv
import io
import datetime as dt
from ..ui import page_auto
from typing import List

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import select, desc

from ..db import get_db
from ..models import Handover, HandoverItem, Priority
from ..auth import require_writer, current_actor
from ..audit import write_log, snapshot

router = APIRouter(prefix="/handover", tags=["handover"])

@router.get("", response_class=HTMLResponse)
def list_handovers(db: Session = Depends(get_db)):
    rows = db.scalars(select(Handover).order_by(desc(Handover.handed_at))).all()
    tr = []
    for h in rows:
        tr.append(
            f"<tr>"
            f"<td>{h.handed_at:%Y-%m-%d %H:%M}</td>"
            f"<td>{h.from_person} → {h.to_person}</td>"
            f"<td><small>{(h.notes or '').replace('<','&lt;')}</small></td>"
            f"<td><a href='/handover/{h.id}'>View / Print</a></td>"
            f"</tr>"
        )
    html = f"""
    <html><body style="font-family: system-ui; max-width: 1000px; margin: 2rem auto;">
      <h2>Handovers</h2>
      <div style="margin-bottom:1rem;">
        <a href="/handover/new">+ New handover</a> · <a href="/handover/export.csv">Export CSV</a>
      </div>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>When</th><th>From → To</th><th>Notes</th><th>Actions</th></tr></thead>
        <tbody>{''.join(tr) or "<tr><td colspan='4'>No handovers yet.</td></tr>"}</tbody>
      </table>
      <p style="margin-top:1rem;"><a href="/">Back</a></p>
    </body></html>
    """
    return page_auto(html)

@router.get("/new", response_class=HTMLResponse)
def new_handover_form(ok: bool = Depends(require_writer)):
    now = dt.datetime.now().isoformat(timespec="minutes")
    html = f"""
    <html><body style="font-family: system-ui; max-width: 720px; margin: 2rem auto;">
      <h2>New Handover</h2>
      <form method="post" action="/handover/new">
        <label>When<br><input name="handed_at" type="datetime-local" value="{now}" required></label><br><br>
        <label>From<br><input name="from_person" required></label><br><br>
        <label>To<br><input name="to_person" required></label><br><br>
        <label>Notes<br><textarea name="notes" rows="3"></textarea></label><br><br>

        <h3>Items</h3>
        <p>Add up to 10 items now; you can edit later.</p>
        <table border="1" cellpadding="6" cellspacing="0" width="100%">
          <thead><tr><th>Title</th><th>Priority</th><th>Comment</th></tr></thead>
          <tbody>
            {"".join([f"<tr><td><input name='title_{i}'></td><td><select name='prio_{i}'><option>HIGH</option><option selected>MEDIUM</option><option>LOW</option></select></td><td><input name='comment_{i}'></td></tr>" for i in range(1,11)])}
          </tbody>
        </table>
        <div style="margin-top:1rem;">
          <button type="submit">Save handover</button>
          <a href="/handover">Cancel</a>
        </div>
      </form>
    </body></html>
    """
    return page_auto(html)

@router.post("/new")
async def create_handover(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    request: Request = None,
    db: Session = Depends(get_db),
):
    form = dict((await request.form()) if request is not None else {})
    handed_at = form.get("handed_at")
    from_person = (form.get("from_person") or "").strip()
    to_person = (form.get("to_person") or "").strip()
    notes = (form.get("notes") or "").strip()
    h = Handover(
        handed_at=dt.datetime.fromisoformat(handed_at) if handed_at else dt.datetime.utcnow(),
        from_person=from_person,
        to_person=to_person,
        notes=notes,
    )
    db.add(h)
    db.flush()
    # items
    created_items: List[HandoverItem] = []
    for i in range(1, 50):
        t = (form.get(f"title_{i}") or "").strip()
        if not t:
            if i > 10:
                break
            continue
        pr = (form.get(f"prio_{i}") or "MEDIUM").strip()
        cm = (form.get(f"comment_{i}") or "").strip()
        it = HandoverItem(handover_id=h.id, title=t, priority=Priority(pr), comment=cm)
        db.add(it)
        created_items.append(it)
    db.flush()

    write_log(db, actor=actor, entity="Handover", entity_id=h.id, action="CREATED", after_obj=h, summary=f"Handover {h.from_person} → {h.to_person} ({len(created_items)} items)")
    for it in created_items:
        write_log(db, actor=actor, entity="HandoverItem", entity_id=it.id, action="CREATED", after_obj=it, summary=f"Item '{it.title}'")
    db.commit()
    return RedirectResponse(url=f"/handover/{h.id}", status_code=303)

@router.get("/{hid}", response_class=HTMLResponse)
def view_handover(hid: int, db: Session = Depends(get_db)):
    h = db.get(Handover, hid)
    if not h:
        raise HTTPException(status_code=404, detail="Not found")
    items = db.scalars(select(HandoverItem).where(HandoverItem.handover_id == h.id).order_by(HandoverItem.priority.asc(), HandoverItem.id.asc())).all()
    rows = []
    for it in items:
        rows.append(f"<tr><td>{it.title}</td><td>{it.priority.value}</td><td><small>{(it.comment or '').replace('<','&lt;')}</small></td></tr>")
    html = f"""
    <html>
    <head>
      <title>Handover {h.handed_at:%Y-%m-%d %H:%M}</title>
      <style>
        @media print {{
          .noprint {{ display: none; }}
        }}
      </style>
    </head>
    <body style="font-family: system-ui; max-width: 800px; margin: 2rem auto;">
      <div class="noprint" style="margin-bottom:1rem;"><a href="/handover">Back</a> · <a href="/handover/export.csv">Export CSV</a> · <a href="#" onclick="window.print();return false;">Print</a></div>
      <h2>Handover</h2>
      <p><b>When:</b> {h.handed_at:%Y-%m-%d %H:%M}</p>
      <p><b>From:</b> {h.from_person} &nbsp; <b>To:</b> {h.to_person}</p>
      <p><b>Notes:</b> <small>{(h.notes or '').replace('<','&lt;')}</small></p>
      <h3>Items</h3>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>Title</th><th>Priority</th><th>Comment</th></tr></thead>
        <tbody>{''.join(rows) or "<tr><td colspan='3'>No items.</td></tr>"}</tbody>
      </table>
    </body></html>
    """
    return page_auto(html)

@router.get("/export.csv")
def export_handover_csv(db: Session = Depends(get_db)):
    # export flattened rows: one row per item; if no items, still one row for handover
    rows = []
    handovers = db.scalars(select(Handover).order_by(Handover.handed_at.asc())).all()
    for h in handovers:
        items = db.scalars(select(HandoverItem).where(HandoverItem.handover_id == h.id).order_by(HandoverItem.id.asc())).all()
        if not items:
            rows.append((h.handed_at.isoformat(), h.from_person, h.to_person, h.notes or "", "", "", ""))
        else:
            for it in items:
                rows.append((h.handed_at.isoformat(), h.from_person, h.to_person, h.notes or "", it.title, it.priority.value, it.comment or ""))

    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["handed_at", "from", "to", "handover_notes", "item_title", "item_priority", "item_comment"])
    for r in rows:
        w.writerow([r[0], r[1], r[2], (r[3] or "").replace("\n", " ").strip(), r[4], r[5], (r[6] or "").replace("\n"," ").strip()])
    buf.seek(0)
    headers = {"Content-Disposition": "attachment; filename=handover_export.csv"}
    return StreamingResponse(iter([buf.read()]), media_type="text/csv", headers=headers)

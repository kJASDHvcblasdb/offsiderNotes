from __future__ import annotations
from ..ui import page_auto
import csv
import io
import datetime as dt
from ..ui import page_auto
from typing import List

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import select, desc, func

from ..db import get_db
from ..models import DailyUsage, Bit, Shroud, BitStatus
from ..auth import require_writer, current_actor
from ..audit import write_log, snapshot

router = APIRouter(prefix="/usage", tags=["usage"])

def status_color(status: BitStatus) -> str:
    return {
        BitStatus.NEW: "#2a9d8f",
        BitStatus.USED: "#f9c74f",
        BitStatus.VERY_USED: "#f9844a",
        BitStatus.NEEDS_RESHARPEN: "#1f6feb",
        BitStatus.SHARPENED: "#007f5f",
        BitStatus.EOL: "#8b0000",
    }[status]

def most_recent_shroud_id_for_bit(db: Session, bit_id: int | None) -> int | None:
    if not bit_id:
        return None
    u = db.scalar(
        select(DailyUsage.shroud_id)
        .where(DailyUsage.bit_id == bit_id)
        .order_by(desc(DailyUsage.date), desc(DailyUsage.id))
        .limit(1)
    )
    return u

@router.get("", response_class=HTMLResponse)
def list_usage(db: Session = Depends(get_db)):
    uses = db.scalars(
        select(DailyUsage).order_by(desc(DailyUsage.date), desc(DailyUsage.id)).limit(300)
    ).all()
    rows: List[str] = []
    for u in uses:
        b = u.bit
        s = u.shroud
        color = status_color(b.status) if b else "#666"
        bit_label = "(deleted bit)" if not b else f"{b.bit_number}{(' — ' + str(b.diameter_mm) + 'mm') if b.diameter_mm else ''}"
        shroud_label = "-" if not s else f"{s.size_mm:g} mm"
        rows.append(
            "<tr>"
            f"<td>{u.date}</td>"
            f"<td><span style='color:#fff;background:{color};padding:2px 6px;border-radius:4px;'>{b.status.value.replace('_',' ').title() if b else 'N/A'}</span> {bit_label}</td>"
            f"<td>{shroud_label}</td>"
            f"<td style='text-align:right;'>{u.meters_drilled:g} m</td>"
            f"<td>{u.prepared_by or ''}</td>"
            f"<td><small>{u.notes or ''}</small></td>"
            "</tr>"
        )
    html = f"""
    <html><body style="font-family: system-ui; max-width: 1200px; margin: 2rem auto;">
      <h2>Daily Usage</h2>
      <div style="display:flex; gap:1rem; align-items:center; margin-bottom:1rem;">
        <a href="/usage/new">+ New usage</a>
        <a href="/usage/bulk">Bulk entry</a>
        <a href="/usage/export.csv">Export CSV</a>
      </div>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead>
          <tr><th>Date</th><th>Bit</th><th>Shroud</th><th>Meters</th><th>Prepared by</th><th>Notes</th></tr>
        </thead>
        <tbody>{''.join(rows) or "<tr><td colspan='6'>No usage logged.</td></tr>"}</tbody>
      </table>
      <p style="margin-top:1rem;"><a href="/">Back</a></p>
    </body></html>
    """
    return page_auto(html)

@router.get("/new", response_class=HTMLResponse)
def new_usage_form(
    db: Session = Depends(get_db),
    ok: bool = Depends(require_writer),
    bit_id: int | None = Query(default=None),
):
    bits = db.scalars(select(Bit).order_by(Bit.bit_number.asc())).all()
    shrouds = db.scalars(select(Shroud).order_by(Shroud.size_mm.asc())).all()

    def bit_opt(b: Bit) -> str:
        sel = "selected" if (bit_id and b.id == bit_id) else ""
        lab = f"{b.bit_number}{(' (' + str(b.diameter_mm) + 'mm)') if b.diameter_mm else ''}"
        return f"<option value='{b.id}' {sel}>{lab}</option>"

    selected_shroud_id = most_recent_shroud_id_for_bit(db, bit_id)

    def shroud_opt(s: Shroud) -> str:
        sel = "selected" if (selected_shroud_id and s.id == selected_shroud_id) else ""
        return f"<option value='{s.id}' {sel}>{s.size_mm:g}mm ({s.condition.value})</option>"

    today = dt.date.today().isoformat()
    html = f"""
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>New Usage</h2>
      <form method="post" action="/usage/new">
        <label>Date<br><input name="date" type="date" value="{today}"></label><br><br>
        <label>Bit<br>
          <select name="bit_id" required>{''.join([bit_opt(b) for b in bits])}</select>
        </label><br><br>
        <label>Shroud<br>
          <select name="shroud_id" required>{''.join([shroud_opt(s) for s in shrouds])}</select>
        </label><br><br>
        <label>Meters drilled<br><input name="meters_drilled" type="number" step="any" required></label><br><br>
        <label>Prepared by<br><input name="prepared_by"></label><br><br>
        <label>Notes<br><textarea name="notes" rows="3" placeholder="e.g., debuttoned"></textarea></label><br><br>
        <button type="submit">Save</button>
        <a href="/usage">Cancel</a>
      </form>
    </body></html>
    """
    return page_auto(html)

@router.post("/new")
def create_usage(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    date: str = Form(...),
    bit_id: int = Form(...),
    shroud_id: int = Form(...),
    meters_drilled: float = Form(...),
    prepared_by: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    b = db.get(Bit, bit_id)
    s = db.get(Shroud, shroud_id)
    if not b or not s:
        raise HTTPException(status_code=400, detail="Invalid bit or shroud")
    u = DailyUsage(
        date=dt.date.fromisoformat(date),
        bit_id=b.id,
        shroud_id=s.id,
        meters_drilled=meters_drilled,
        prepared_by=prepared_by.strip(),
        notes=notes.strip(),
    )
    db.add(u)

    before = snapshot(b)
    b.total_meters = float(b.total_meters or 0) + float(meters_drilled or 0)
    b.last_used = u.date
    # keep any resharpen/EOL decisions manual; only gentle escalate
    if b.expected_life_m and b.status in (BitStatus.NEW, BitStatus.USED, BitStatus.VERY_USED):
        frac = (b.total_meters or 0) / b.expected_life_m
        if frac >= 1.0 and b.status != BitStatus.EOL:
            b.status = BitStatus.VERY_USED
        elif frac >= 0.8 and b.status == BitStatus.USED:
            b.status = BitStatus.VERY_USED

    db.flush()
    write_log(db, actor=actor, entity="DailyUsage", entity_id=u.id, action="CREATED", after_obj=u,
              summary=f"Usage {b.bit_number} {meters_drilled:g}m (shroud {s.size_mm:g}mm)")
    write_log(db, actor=actor, entity="Bit", entity_id=b.id, action="ADJUSTED", before_obj=before, after_obj=b,
              summary=f"Bit {b.bit_number} +{meters_drilled:g}m (usage log)")
    db.commit()
    return RedirectResponse(url="/usage", status_code=303)

@router.get("/bulk", response_class=HTMLResponse)
def bulk_usage_form(db: Session = Depends(get_db), ok: bool = Depends(require_writer)):
    bits = db.scalars(select(Bit).order_by(Bit.bit_number.asc())).all()
    shrouds = db.scalars(select(Shroud).order_by(Shroud.size_mm.asc())).all()

    bit_opts = "".join([f"<option value='{b.id}'>{b.bit_number}{(' (' + str(b.diameter_mm) + 'mm)') if b.diameter_mm else ''}</option>" for b in bits])
    shroud_opts = "".join([f"<option value='{s.id}'>{s.size_mm:g}mm ({s.condition.value})</option>" for s in shrouds])

    today = dt.date.today().isoformat()
    rows = []
    for i in range(1, 6):
        rows.append(
            f"<tr>"
            f"<td><input name='date_{i}' type='date' value='{today}'></td>"
            f"<td><select name='bit_id_{i}'>{bit_opts}</select></td>"
            f"<td><select name='shroud_id_{i}'>{shroud_opts}</select></td>"
            f"<td><input name='meters_{i}' type='number' step='any' placeholder='m'></td>"
            f"<td><input name='by_{i}' placeholder='prepared by'></td>"
            f"<td><input name='note_{i}' placeholder='notes'></td>"
            f"</tr>"
        )
    html = f"""
    <html><body style="font-family: system-ui; max-width: 1000px; margin: 2rem auto;">
      <h2>Bulk Usage Entry</h2>
      <form method="post" action="/usage/bulk">
        <table border="1" cellpadding="6" cellspacing="0" width="100%">
          <thead><tr><th>Date</th><th>Bit</th><th>Shroud</th><th>Meters</th><th>Prepared by</th><th>Notes</th></tr></thead>
          <tbody>{''.join(rows)}</tbody>
        </table>
        <div style="margin-top:1rem;">
          <button type="submit">Save all</button>
          <a href="/usage">Cancel</a>
        </div>
      </form>
    </body></html>
    """
    return page_auto(html)

@router.post("/bulk")
async def bulk_usage_submit(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    request: Request = None,
    db: Session = Depends(get_db),
):
    form = dict((await request.form()) if request is not None else {})
    created = 0
    for i in range(1, 50):
        key_m = f"meters_{i}"
        if key_m not in form:
            break
        meters_raw = (form.get(key_m) or "").strip()
        if meters_raw == "":
            continue
        try:
            meters = float(meters_raw)
        except ValueError:
            continue
        date_s = (form.get(f"date_{i}") or dt.date.today().isoformat())
        bit_id_s = form.get(f"bit_id_{i}")
        shroud_id_s = form.get(f"shroud_id_{i}")
        if not bit_id_s or not shroud_id_s:
            continue
        b = db.get(Bit, int(bit_id_s))
        s = db.get(Shroud, int(shroud_id_s))
        if not b or not s:
            continue
        u = DailyUsage(
            date=dt.date.fromisoformat(date_s),
            bit_id=b.id,
            shroud_id=s.id,
            meters_drilled=meters,
            prepared_by=(form.get(f"by_{i}") or "").strip(),
            notes=(form.get(f"note_{i}") or "").strip(),
        )
        db.add(u)

        before = snapshot(b)
        b.total_meters = float(b.total_meters or 0) + meters
        b.last_used = u.date if (not b.last_used or u.date > b.last_used) else b.last_used
        if b.expected_life_m and b.status in (BitStatus.NEW, BitStatus.USED, BitStatus.VERY_USED):
            frac = (b.total_meters or 0) / b.expected_life_m
            if frac >= 1.0 and b.status != BitStatus.EOL:
                b.status = BitStatus.VERY_USED
            elif frac >= 0.8 and b.status == BitStatus.USED:
                b.status = BitStatus.VERY_USED

        db.flush()
        write_log(db, actor=actor, entity="DailyUsage", entity_id=u.id, action="CREATED", after_obj=u,
                  summary=f"Usage {b.bit_number} {meters:g}m (bulk)")
        write_log(db, actor=actor, entity="Bit", entity_id=b.id, action="ADJUSTED", before_obj=before, after_obj=b,
                  summary=f"Bit {b.bit_number} +{meters:g}m (bulk)")
        created += 1

    db.commit()
    return RedirectResponse(url="/usage", status_code=303)

@router.get("/export.csv")
def export_usage_csv(db: Session = Depends(get_db)):
    rows = db.execute(
        select(
            DailyUsage.date,
            Bit.bit_number,
            Bit.diameter_mm,
            Shroud.size_mm,
            DailyUsage.meters_drilled,
            DailyUsage.prepared_by,
            DailyUsage.notes,
        )
        .join(Bit, Bit.id == DailyUsage.bit_id)
        .join(Shroud, Shroud.id == DailyUsage.shroud_id)
        .order_by(DailyUsage.date.asc(), DailyUsage.id.asc())
    ).all()

    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["date", "bit_serial", "bit_diameter_mm", "shroud_mm", "meters", "prepared_by", "notes"])
    for r in rows:
        date, serial, dia, sh, m, who, note = r
        w.writerow([date or "", serial or "", dia or "", sh or "", f"{m:g}", who or "", note or ""])
    buf.seek(0)
    headers = {"Content-Disposition": "attachment; filename=usage_export.csv"}
    return StreamingResponse(iter([buf.read()]), media_type="text/csv", headers=headers)

from __future__ import annotations
from ..ui import page_auto
import csv
import io
import datetime as dt

from ..ui import page_auto
from fastapi import APIRouter, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import select, desc

from ..db import get_db
from ..models import RefuelLog
from ..auth import require_writer, current_actor
from ..audit import write_log

router = APIRouter(prefix="/refuel", tags=["refuel"])

@router.get("", response_class=HTMLResponse)
def list_refuels(db: Session = Depends(get_db)):
    rows = db.scalars(select(RefuelLog).order_by(desc(RefuelLog.when))).all()
    tr = []
    for r in rows:
        notes = (r.notes or "").replace("<", "&lt;")
        tr.append(
            f"<tr>"
            f"<td>{r.when:%Y-%m-%d %H:%M}</td>"
            f"<td style='text-align:right;'>{r.before_L if r.before_L is not None else ''}</td>"
            f"<td style='text-align:right;'>{r.added_L if r.added_L is not None else ''}</td>"
            f"<td style='text-align:right;'>{r.after_L if r.after_L is not None else ''}</td>"
            f"<td>{r.next_due_at or ''}</td>"
            f"<td><small>{notes}</small></td>"
            f"</tr>"
        )
    html = f"""
    <html><body style="font-family: system-ui; max-width: 1100px; margin: 2rem auto;">
      <h2>Refuel Log</h2>
      <div style="margin-bottom:1rem;">
        <a href="/refuel/new">+ New refuel</a> · <a href="/refuel/export.csv">Export CSV</a>
      </div>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>When</th><th>Before (L)</th><th>Added (L)</th><th>After (L)</th><th>Next due</th><th>Notes</th></tr></thead>
        <tbody>{''.join(tr) or "<tr><td colspan='6'>No refuels logged.</td></tr>"}</tbody>
      </table>
      <p style="margin-top:1rem;"><a href="/">Back</a></p>
    </body></html>
    """
    return page_auto(html)

@router.get("/new", response_class=HTMLResponse)
def new_refuel_form(ok: bool = Depends(require_writer)):
    now = dt.datetime.now().isoformat(timespec="minutes")
    html = f"""
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>New Refuel</h2>
      <form method="post" action="/refuel/new">
        <label>When<br><input name="when" type="datetime-local" value="{now}" required></label><br><br>
        <label>Before (L)<br><input name="before_L" type="number" step="any"></label><br><br>
        <label>Added (L)<br><input name="added_L" type="number" step="any"></label><br><br>
        <label>After (L)<br><input name="after_L" type="number" step="any"></label><br><br>
        <label>Next due (date, optional)<br><input name="next_due_at" type="date"></label><br><br>
        <label>Notes<br><textarea name="notes" rows="3"></textarea></label><br><br>
        <button type="submit">Save</button>
        <a href="/refuel">Cancel</a>
      </form>
    </body></html>
    """
    return page_auto(html)

@router.post("/new")
def create_refuel(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    when: str = Form(...),
    before_L: str = Form(""),
    added_L: str = Form(""),
    after_L: str = Form(""),
    next_due_at: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    row = RefuelLog(
        when=dt.datetime.fromisoformat(when),
        before_L=(float(before_L) if before_L.strip() else None),
        added_L=(float(added_L) if added_L.strip() else None),
        after_L=(float(after_L) if after_L.strip() else None),
        next_due_at=(dt.date.fromisoformat(next_due_at) if next_due_at.strip() else None),
        notes=notes.strip(),
    )
    db.add(row)
    db.flush()
    summary = f"Refuel {row.added_L or ''}L, after={row.after_L or ''}L"
    write_log(db, actor=actor, entity="RefuelLog", entity_id=row.id, action="CREATED", after_obj=row, summary=summary)
    db.commit()
    return RedirectResponse(url="/refuel", status_code=303)

@router.get("/export.csv")
def export_refuel_csv(db: Session = Depends(get_db)):
    rows = db.scalars(select(RefuelLog).order_by(RefuelLog.when.asc())).all()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["when", "before_L", "added_L", "after_L", "next_due_at", "notes"])
    for r in rows:
        w.writerow([r.when.isoformat(), r.before_L or "", r.added_L or "", r.after_L or "", r.next_due_at or "", (r.notes or "").replace("\n"," ").strip()])
    buf.seek(0)
    headers = {"Content-Disposition": "attachment; filename=refuel_export.csv"}
    return StreamingResponse(iter([buf.read()]), media_type="text/csv", headers=headers)

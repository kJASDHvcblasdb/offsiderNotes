from __future__ import annotations
from ..ui import page_auto

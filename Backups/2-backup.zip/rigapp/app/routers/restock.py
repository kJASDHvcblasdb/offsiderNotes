from __future__ import annotations

import io, csv

import datetime as dt
from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..db import get_db
from ..models import RestockItem, StockItem, Priority
from ..auth import require_writer, current_actor
from ..audit import write_log, snapshot
from ..utils import effective_thresholds, stock_status, compute_days_until_min, eta_date

router = APIRouter(prefix="/restock", tags=["restock"])

# --------- List ---------

@router.get("", response_class=HTMLResponse)
def restock_list(status: str | None = None, priority: str | None = None, db: Session = Depends(get_db)):
    stmt = select(RestockItem).order_by(RestockItem.is_closed.asc(), RestockItem.priority.desc(), RestockItem.created_at.desc())
    rows = db.scalars(stmt).all()
    def pri_badge(p: Priority) -> str:
        color = {"HIGH":"#d33","MEDIUM":"#f9844a","LOW":"#2a9d8f"}[p.value]
        return f"<span style='color:#fff;background:{color};padding:2px 6px;border-radius:4px;'>{p.value}</span>"

    lis = []
    for r in rows:
        if status == "open" and r.is_closed: 
            continue
        if status == "closed" and not r.is_closed:
            continue
        if priority and r.priority.value != priority.upper():
            continue
        si = r.stock_item
        needed_by = f" (needed by {r.needed_by_date})" if r.needed_by_date else ""
        state = "CLOSED" if r.is_closed else "OPEN"
        close_btn = "" if r.is_closed else (
            f"<form method='post' action='/restock/{r.id}/close' style='display:inline;margin-left:6px;'>"
            f"<input type='number' step='any' name='received_qty' placeholder='received' style='width:7em;'/>"
            f"<button type='submit'>Close</button></form>"
        )
        edit_link = f"<a href='/restock/{r.id}/edit'>Edit</a>"
        lis.append(
            f"<tr>"
            f"<td>{pri_badge(r.priority)} {state}</td>"
            f"<td>{(si.name if si else '(deleted)')}</td>"
            f"<td>req: {r.requested_qty:g}{' ' + (si.unit if si else '')}{needed_by}<br><small>{r.notes or ''}</small></td>"
            f"<td>{edit_link} {close_btn}</td>"
            f"</tr>"
        )
    html = f"""
    <html><body style="font-family: system-ui; max-width: 1000px; margin: 2rem auto;">
      <h2>Restock</h2>
      <form method="get" action="/restock" style="margin-bottom:1rem;">
        <select name="status">
          <option value="">All</option>
          <option value="open" {'selected' if status=='open' else ''}>Open</option>
          <option value="closed" {'selected' if status=='closed' else ''}>Closed</option>
        </select>
        <select name="priority">
          <option value="">Any priority</option>
          <option value="HIGH" {'selected' if (priority or '').upper()=='HIGH' else ''}>High</option>
          <option value="MEDIUM" {'selected' if (priority or '').upper()=='MEDIUM' else ''}>Medium</option>
          <option value="LOW" {'selected' if (priority or '').upper()=='LOW' else ''}>Low</option>
        </select>
        <button type="submit">Filter</button>
        <a href="/restock/new" style="float:right;">+ New restock</a>
      </form>
      <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <thead><tr><th>Status/Priority</th><th>Item</th><th>Details</th><th>Actions</th></tr></thead>
        <tbody>{''.join(lis) or "<tr><td colspan='4'>No restocks.</td></tr>"}</tbody>
      </table>
      <p style="margin-top:1rem;"><a href="/">Back</a></p>
    </body></html>
    """
    return HTMLResponse(html)

# --------- Create (prefill based on stock status/usage) ---------

@router.get("/new", response_class=HTMLResponse)
def restock_new_form(
    stock_item_id: int | None = None,
    ok: bool = Depends(require_writer),
    db: Session = Depends(get_db),
):
    stock = db.get(StockItem, stock_item_id) if stock_item_id else None

    # Build item options
    options = []
    for it in db.scalars(select(StockItem).order_by(StockItem.name.asc())).all():
        sel = "selected" if stock and it.id == stock.id else ""
        options.append(f"<option value='{it.id}' {sel}>{it.name}</option>")

    # Defaults
    default_qty = ""
    default_priority = "MEDIUM"
    default_needed_by = ""

    if stock:
        eff_min, eff_buf = effective_thresholds(db, stock)
        shortfall = (eff_min + eff_buf) - (stock.on_rig_qty or 0)
        if shortfall < 0:
            shortfall = 0
        default_qty = f"{shortfall:g}"

        st = stock_status(db, stock)
        if st == "critical":
            default_priority = "HIGH"
        elif st == "low":
            default_priority = "MEDIUM"
        elif st == "watch":
            default_priority = "LOW"
        else:
            default_priority = "LOW"

        dmin = compute_days_until_min(db, stock)
        hit_min = eta_date(dmin) if dmin is not None else None
        if hit_min:
            default_needed_by = hit_min

    def sel(v: str) -> str:
        return "selected" if v == default_priority else ""

    html = f"""
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>New Restock</h2>
      <form method="post" action="/restock/new">
        <label>Stock Item<br>
          <select name="stock_item_id" required>
            {''.join(options)}
          </select>
        </label><br><br>

        <label>Requested qty<br>
          <input name="requested_qty" type="number" step="any" value="{default_qty}">
        </label><br><br>

        <label>Priority<br>
          <select name="priority">
            <option value="HIGH" {sel('HIGH')}>High</option>
            <option value="MEDIUM" {sel('MEDIUM')}>Medium</option>
            <option value="LOW" {sel('LOW')}>Low</option>
          </select>
        </label><br><br>

        <label>Needed by (optional)<br>
          <input name="needed_by" type="date" value="{default_needed_by}">
        </label><br><br>

        <label>Notes<br><textarea name="notes" rows="3"></textarea></label><br><br>

        <button type="submit">Create</button>
        <a href="/restock">Cancel</a>
      </form>
    </body></html>
    """
    return HTMLResponse(html)

@router.post("/new")
def restock_new(
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    stock_item_id: int = Form(...),
    requested_qty: float = Form(...),
    priority: str = Form("MEDIUM"),
    needed_by: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    si = db.get(StockItem, stock_item_id)
    if not si:
        raise HTTPException(status_code=404, detail="Stock item not found")
    r = RestockItem(
        stock_item_id=si.id,
        requested_qty=float(requested_qty or 0),
        priority=Priority(priority.upper()),
        needed_by_date=dt.date.fromisoformat(needed_by) if needed_by else None,
        notes=notes.strip(),
        is_closed=False,
    )
    db.add(r)
    db.flush()
    write_log(db, actor=actor, entity="RestockItem", entity_id=r.id, action="CREATED", after_obj=r, summary=f"Restock for '{si.name}' qty {r.requested_qty:g} ({r.priority.value})")
    db.commit()
    return RedirectResponse(url="/restock", status_code=303)

# --------- Edit ---------

@router.get("/{rid}/edit", response_class=HTMLResponse)
def restock_edit_form(rid: int, ok: bool = Depends(require_writer), db: Session = Depends(get_db)):
    r = db.get(RestockItem, rid)
    if not r:
        raise HTTPException(status_code=404, detail="Not found")
    si = r.stock_item
    options = []
    for it in db.scalars(select(StockItem).order_by(StockItem.name.asc())).all():
        sel = "selected" if si and it.id == si.id else ""
        options.append(f"<option value='{it.id}' {sel}>{it.name}</option>")
    nd = r.needed_by_date.isoformat() if r.needed_by_date else ""
    html = f"""
    <html><body style="font-family: system-ui; max-width: 640px; margin: 2rem auto;">
      <h2>Edit Restock</h2>
      <form method="post" action="/restock/{r.id}/edit">
        <label>Stock Item<br>
          <select name="stock_item_id">{''.join(options)}</select>
        </label><br><br>
        <label>Requested qty<br><input name="requested_qty" type="number" step="any" value="{r.requested_qty}"></label><br><br>
        <label>Priority<br>
          <select name="priority">
            <option value="HIGH" {'selected' if r.priority.value=='HIGH' else ''}>High</option>
            <option value="MEDIUM" {'selected' if r.priority.value=='MEDIUM' else ''}>Medium</option>
            <option value="LOW" {'selected' if r.priority.value=='LOW' else ''}>Low</option>
          </select>
        </label><br><br>
        <label>Needed by<br><input name="needed_by" type="date" value="{nd}"></label><br><br>
        <label>Notes<br><textarea name="notes" rows="3">{r.notes or ''}</textarea></label><br><br>
        <label>Closed <input type="checkbox" name="is_closed" {'checked' if r.is_closed else ''}></label><br><br>
        <button type="submit">Save</button>
        <a href="/restock">Cancel</a>
      </form>
    </body></html>
    """
    return HTMLResponse(html)

@router.post("/{rid}/edit")
def restock_edit(
    rid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    stock_item_id: int = Form(...),
    requested_qty: float = Form(...),
    priority: str = Form("MEDIUM"),
    needed_by: str = Form(""),
    notes: str = Form(""),
    is_closed: str = Form(""),
    db: Session = Depends(get_db),
):
    r = db.get(RestockItem, rid)
    if not r:
        raise HTTPException(status_code=404, detail="Not found")
    before = snapshot(r)
    r.stock_item_id = int(stock_item_id)
    r.requested_qty = float(requested_qty or 0)
    r.priority = Priority(priority.upper())
    r.needed_by_date = dt.date.fromisoformat(needed_by) if needed_by else None
    r.notes = notes.strip()
    r.is_closed = bool(is_closed)
    write_log(db, actor=actor, entity="RestockItem", entity_id=r.id, action="UPDATED", before_obj=before, after_obj=r, summary=f"Updated restock #{r.id}")
    db.commit()
    return RedirectResponse(url="/restock", status_code=303)

# --------- Close (optionally bump stock qty) ---------

@router.post("/{rid}/close")
def restock_close(
    rid: int,
    ok: bool = Depends(require_writer),
    actor: str = Depends(current_actor),
    received_qty: float | None = Form(None),
    db: Session = Depends(get_db),
):
    r = db.get(RestockItem, rid)
    if not r:
        raise HTTPException(status_code=404, detail="Not found")
    if r.is_closed:
        return RedirectResponse(url="/restock", status_code=303)
    si = r.stock_item
    before_r = snapshot(r)
    before_stock = snapshot(si) if si else {}

    r.is_closed = True
    r.closed_at = dt.datetime.utcnow()

    bump_msg = ""
    if si and received_qty is not None:
        try:
            received_qty = float(received_qty)
        except Exception:
            received_qty = None
        if received_qty is not None:
            si.on_rig_qty = float(si.on_rig_qty or 0) + received_qty
            si.last_updated_at = dt.datetime.utcnow()
            bump_msg = f" + stock '{si.name}' +{received_qty:g}"

    write_log(
        db,
        actor=actor,
        entity="RestockItem",
        entity_id=r.id,
        action="CLOSED",
        before_obj=before_r,
        after_obj=r,
        summary=f"Closed restock #{r.id}{bump_msg}",
    )
    if si and bump_msg:
        write_log(
            db,
            actor=actor,
            entity="StockItem",
            entity_id=si.id,
            action="ADJUSTED",
            before_obj=before_stock,
            after_obj=si,
            summary=f"Restock received → '{si.name}' qty {before_stock.get('on_rig_qty',0):g}->{si.on_rig_qty:g}",
        )

    db.commit()
    return RedirectResponse(url="/restock", status_code=303)

@router.get("/export.csv")
def export_restock_csv(db: Session = Depends(get_db)):
    rows = db.scalars(select(RestockItem).order_by(RestockItem.created_at.asc())).all()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id","stock_item","quantity","priority","is_closed","created_at","closed_at","notes"])
    for r in rows:
        w.writerow([
            r.id, (r.stock_item.name if r.stock_item else ""), r.quantity or "",
            r.priority or "", "yes" if r.is_closed else "no",
            r.created_at, r.closed_at or "", (r.notes or "").replace("\n"," ").strip()
        ])
    buf.seek(0)
    headers = {"Content-Disposition": "attachment; filename=restock_export.csv"}
    return StreamingResponse(iter([buf.read()]), media_type="text/csv", headers=headers)

from __future__ import annotations
import re
from fastapi.responses import HTMLResponse

_H1_RE = re.compile(r"<h1[^>]*>(.*?)</h1>", re.IGNORECASE | re.DOTALL)

def page(title: str, body_html: str) -> HTMLResponse:
    """Full HTML doc with CSS and a specific title."""
    html = f"""
    <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="/static/style.css">
        <title>{title}</title>
      </head>
      <body class="container">
        {body_html}
      </body>
    </html>
    """
    return HTMLResponse(html)

def page_auto(body_html: str, fallback_title: str = "Rig App") -> HTMLResponse:
    """Full HTML doc; title taken from first <h1> if present, else fallback."""
    # Extract first <h1>…</h1> as the title if available
    m = _H1_RE.search(body_html or "")
    title = m.group(1).strip() if m else fallback_title
    # Strip tags from title if any
    title = re.sub("<[^<]+?>", "", title)
    return page(title, body_html)

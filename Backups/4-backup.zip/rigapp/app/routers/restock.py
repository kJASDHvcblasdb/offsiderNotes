# rigapp/app/routers/restock.py
from __future__ import annotations

from fastapi import APIRouter, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select

from ..db import get_db
from ..models import RestockItem, StockItem
from ..auth import require_reader, current_actor, current_rig_title
from ..audit import write_log

router = APIRouter(prefix="/restock", tags=["restock"])

def _wrap(title: str, body: str, rig: str, actor: str) -> HTMLResponse:
    html = f"""
    <html><head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="/static/style.css"><title>{title}</title>
    </head><body class="container">
      <h1>{title}</h1>
      <p class="muted">Rig: <strong>{rig}</strong> · Crew: <strong>{actor}</strong></p>
      {body}
    </body></html>
    """
    return HTMLResponse(html)

@router.get("", response_class=HTMLResponse)
def restock_index(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    items = db.scalars(select(RestockItem).order_by(RestockItem.is_closed, RestockItem.priority, RestockItem.id.desc())).all()
    rows = []
    for r in items:
        name = r.name
        if r.stock_item:
            name = f"{r.stock_item.name} ({r.stock_item.unit})"
        status = "closed" if r.is_closed else "open"
        rows.append(
            f"<tr><td>{r.id}</td><td>{name}</td><td>{r.qty} {r.unit}</td><td>P{r.priority}</td><td>{status}</td>"
            f"<td>"
            f"<form method='post' action='/restock/{r.id}/toggle' style='display:inline'><button class='btn' type='submit'>{'Reopen' if r.is_closed else 'Close'}</button></form> "
            f"<form method='post' action='/restock/{r.id}/delete' style='display:inline'><button class='btn' type='submit' onclick='return confirm(\"Delete restock #{r.id}?\")'>Delete</button></form>"
            f"</td></tr>"
        )
    table = "<p class='muted'>No restock entries.</p>" if not rows else (
        "<table><thead><tr><th>ID</th><th>Item</th><th>Qty</th><th>Prio</th><th>Status</th><th></th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table>"
    )
    body = f"<p><a class='btn' href='/restock/new'>➕ Add restock item</a></p>{table}"
    return _wrap("Restock", body, rig, actor)

@router.get("/new", response_class=HTMLResponse)
def restock_new_form(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    options = ["<option value=''>— link to stock item (optional) —</option>"]
    for s in db.scalars(select(StockItem).order_by(StockItem.name)).all():
        options.append(f"<option value='{s.id}'>{s.name} ({s.unit})</option>")
    body = f"""
      <form method="post" action="/restock/new" class="form">
        <label>Link stock item
          <select name="stock_item_id">
            {''.join(options)}
          </select>
        </label>
        <label>Free-text item name <input name="name" placeholder="If not linking a stock item"></label>
        <label>Quantity <input type="number" name="qty" value="1"></label>
        <label>Unit <input name="unit" value="ea"></label>
        <label>Priority
          <select name="priority">
            <option value="1">High</option>
            <option value="2" selected>Medium</option>
            <option value="3">Low</option>
          </select>
        </label>
        <div class="actions">
          <button class="btn" type="submit">Save</button>
          <a class="btn" href="/restock">Cancel</a>
        </div>
      </form>
    """
    return _wrap("New Restock Item", body, rig, actor)

@router.post("/new")
def restock_new(
    actor: str = Depends(current_actor),
    stock_item_id: str = Form(""),
    name: str = Form(""),
    qty: int = Form(1),
    unit: str = Form("ea"),
    priority: int = Form(2),
    db=Depends(get_db),
):
    linked = None
    if stock_item_id:
        linked = db.get(StockItem, int(stock_item_id))
    item = RestockItem(
        stock_item_id=(linked.id if linked else None),
        name=name or (linked.name if linked else "Unnamed"),
        qty=qty,
        unit=unit or (linked.unit if linked else "ea"),
        priority=priority,
    )
    db.add(item)
    db.commit()
    write_log(db, actor=actor or "crew", entity="restock", entity_id=item.id, action="create", summary=item.name)
    return RedirectResponse("/restock", status_code=303)

@router.post("/{restock_id}/toggle")
def restock_toggle(
    restock_id: int,
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    r = db.get(RestockItem, restock_id)
    if r:
        r.is_closed = not r.is_closed
        db.commit()
        write_log(db, actor=actor or "crew", entity="restock", entity_id=restock_id, action=("close" if r.is_closed else "reopen"), summary=r.name or "")
    return RedirectResponse("/restock", status_code=303)

@router.post("/{restock_id}/delete")
def restock_delete(
    restock_id: int,
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    r = db.get(RestockItem, restock_id)
    if r:
        name = r.name or ""
        db.delete(r)
        db.commit()
        write_log(db, actor=actor or "crew", entity="restock", entity_id=restock_id, action="delete", summary=name)
    return RedirectResponse("/restock", status_code=303)

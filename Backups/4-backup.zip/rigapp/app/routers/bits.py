# rigapp/app/routers/bits.py
from __future__ import annotations

from fastapi import APIRouter, Depends, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Bit, BitStatus, Shroud
from ..auth import require_reader, current_actor, current_rig_title

router = APIRouter(prefix="/bits", tags=["bits"])

STATUSES = [s.value for s in BitStatus]

def _wrap(title: str, body: str, rig: str, actor: str) -> HTMLResponse:
    html = f"""
    <html><head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="/static/style.css"><title>{title}</title>
    </head><body class="container">
      <h1>{title}</h1>
      <p class="muted">Rig: <strong>{rig}</strong> · Crew: <strong>{actor}</strong></p>
      {body}
    </body></html>
    """
    return HTMLResponse(html)

@router.get("", response_class=HTMLResponse)
def bits_index(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
    db: Session = Depends(get_db),
):
    bits = db.scalars(select(Bit).order_by(Bit.id.desc())).all()
    rows = []
    for b in bits:
        rows.append(
            "<tr>"
            f"<td>{b.serial or ''}</td>"
            f"<td>{(b.status.value if b.status else '')}</td>"
            f"<td>{b.life_meters_expected or ''}</td>"
            f"<td>{b.life_meters_used or ''}</td>"
            f"<td>{b.shroud.name if b.shroud else ''}</td>"
            "</tr>"
        )
    table = (
        "<p class='muted'>No bits yet.</p>"
        if not rows
        else "<table><thead><tr>"
             "<th>Serial</th><th>Status</th><th>Expected life (m)</th><th>Used (m)</th><th>Shroud</th>"
             "</tr></thead>"
             f"<tbody>{''.join(rows)}</tbody></table>"
    )
    body = f"<p><a class='btn' href='/bits/new'>➕ Add bit</a></p>{table}"
    return _wrap("Bits", body, rig, actor)

@router.get("/new", response_class=HTMLResponse)
def bits_new_form(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
    db: Session = Depends(get_db),
):
    status_options = "".join([f"<option value='{s}'>{s}</option>" for s in STATUSES])
    shroud_options = ["<option value=''>— none —</option>"]
    for s in db.scalars(select(Shroud).order_by(Shroud.name)).all():
        shroud_options.append(f"<option value='{s.id}'>{s.name}</option>")
    body = f"""
      <form method="post" action="/bits/new" class="form">
        <label>Serial <input name="serial" required maxlength="120"></label>
        <label>Status
          <select name="status" required>
            {status_options}
          </select>
        </label>
        <label>Expected life (m) <input type="number" name="life_meters_expected" value="0"></label>
        <label>Used (m) <input type="number" name="life_meters_used" value="0"></label>
        <label>Shroud
          <select name="shroud_id">
            {''.join(shroud_options)}
          </select>
        </label>
        <label>Notes <textarea name="notes" rows="3"></textarea></label>
        <div class='actions'>
          <button class="btn" type="submit">Save</button>
          <a class="btn" href="/bits">Cancel</a>
        </div>
      </form>
    """
    return _wrap("New Bit", body, rig, actor)

@router.post("/new")
def bits_new(
    serial: str = Form(...),
    status: str = Form(...),
    life_meters_expected: int = Form(0),
    life_meters_used: int = Form(0),
    shroud_id: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    try:
        status_enum = BitStatus(status)
    except Exception:
        raise HTTPException(status_code=422, detail="Invalid status")

    shroud = None
    if shroud_id:
        shroud = db.get(Shroud, int(shroud_id))

    b = Bit(
        serial=serial,
        status=status_enum,
        life_meters_expected=life_meters_expected or None,
        life_meters_used=life_meters_used or 0,
        shroud_id=(shroud.id if shroud else None),
        notes=notes or None,
    )
    db.add(b)
    db.commit()
    return RedirectResponse("/bits", status_code=303)

# rigapp/app/routers/handover.py
from __future__ import annotations

from fastapi import APIRouter, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select

from ..db import get_db
from ..auth import require_reader, current_actor, current_rig_title
from ..models import HandoverNote
from ..audit import write_log

router = APIRouter(prefix="/handover", tags=["handover"])

def _wrap(title: str, body: str, rig: str, actor: str) -> HTMLResponse:
    html = f"""
    <html><head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="/static/style.css"><title>{title}</title>
    </head><body class="container">
      <h1>{title}</h1>
      <p class="muted">Rig: <strong>{rig}</strong> · Crew: <strong>{actor}</strong></p>
      {body}
    </body></html>
    """
    return HTMLResponse(html)

@router.get("", response_class=HTMLResponse)
def handover_index(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    notes = db.scalars(select(HandoverNote).order_by(HandoverNote.priority, HandoverNote.id.desc())).all()
    rows = []
    for n in notes:
        pr = {1:"High",2:"Med",3:"Low"}.get(n.priority or 2, "Med")
        rows.append(
            f"<tr><td>{n.id}</td><td>P{n.priority} ({pr})</td>"
            f"<td>{n.title or ''}</td><td>{n.author or ''}</td>"
            f"<td>{(n.body or '').replace('<','&lt;')}</td>"
            f"<td>"
            f"<form method='post' action='/handover/{n.id}/delete' style='display:inline'>"
            f"<button class='btn' type='submit' onclick='return confirm(\"Delete note #{n.id}?\")'>Delete</button>"
            f"</form>"
            f"</td></tr>"
        )
    table = "<p class='muted'>No handover notes.</p>" if not rows else (
        "<table><thead><tr><th>ID</th><th>Priority</th><th>Title</th><th>Author</th><th>Body</th><th></th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table>"
    )
    body = f"<p><a class='btn' href='/handover/new'>➕ Add note</a></p>{table}"
    return _wrap("Handover", body, rig, actor)

@router.get("/new", response_class=HTMLResponse)
def handover_new_form(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
):
    body = """
      <form method="post" action="/handover/new" class="form">
        <label>Title <input name="title" required maxlength="200"></label>
        <label>Body <textarea name="body" rows="5"></textarea></label>
        <label>Priority
          <select name="priority">
            <option value="1">High</option>
            <option value="2" selected>Medium</option>
            <option value="3">Low</option>
          </select>
        </label>
        <div class='actions'>
          <button class="btn" type="submit">Save</button>
          <a class="btn" href="/handover">Cancel</a>
        </div>
      </form>
    """
    return _wrap("New Handover Note", body, rig, actor)

@router.post("/new")
def handover_new(
    actor: str = Depends(current_actor),
    title: str = Form(...),
    body: str = Form(""),
    priority: int = Form(2),
    db=Depends(get_db),
):
    n = HandoverNote(title=title, body=(body or None), priority=priority, author=(actor or None))
    db.add(n)
    db.commit()
    write_log(db, actor=actor or "crew", entity="handover", entity_id=n.id, action="create", summary=title)
    return RedirectResponse("/handover", status_code=303)

@router.post("/{note_id}/delete")
def handover_delete(
    note_id: int,
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    n = db.get(HandoverNote, note_id)
    if n:
        db.delete(n)
        db.commit()
        write_log(db, actor=actor or "crew", entity="handover", entity_id=note_id, action="delete", summary=n.title or "")
    return RedirectResponse("/handover", status_code=303)

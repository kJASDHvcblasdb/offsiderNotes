# rigapp/app/routers/stock.py
from __future__ import annotations

from fastapi import APIRouter, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select

from ..db import get_db
from ..auth import require_reader, current_actor, current_rig_title
from ..models import StockItem
from ..audit import write_log

router = APIRouter(prefix="/stock", tags=["stock"])

def _wrap(title: str, body: str, rig: str, actor: str) -> HTMLResponse:
    html = f"""
    <html><head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="/static/style.css"><title>{title}</title>
    </head><body class="container">
      <h1>{title}</h1>
      <p class="muted">Rig: <strong>{rig}</strong> · Crew: <strong>{actor}</strong></p>
      {body}
    </body></html>
    """
    return HTMLResponse(html)

@router.get("", response_class=HTMLResponse)
def stock_index(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    items = db.scalars(select(StockItem).order_by(StockItem.name)).all()
    rows = []
    for s in items:
        rows.append(
            "<tr>"
            f"<td>{s.name}</td><td>{s.on_rig_qty}</td><td>{s.min_qty}</td><td>{s.buffer_qty}</td>"
            f"<td>{s.unit}</td><td>{s.location or ''}</td>"
            f"<td>"
            f"<form method='post' action='/stock/{s.id}/delete' style='display:inline'>"
            f"<button class='btn' type='submit' onclick='return confirm(\"Delete {s.name}?\")'>Delete</button>"
            f"</form>"
            f"</td>"
            "</tr>"
        )
    table = "<p class='muted'>No stock items yet.</p>" if not rows else (
        "<table><thead><tr><th>Name</th><th>On rig</th><th>Min</th><th>Buffer</th><th>Unit</th><th>Location</th><th></th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table>"
    )
    body = f"<p><a class='btn' href='/stock/new'>➕ Add stock item</a></p>{table}"
    return _wrap("Stock", body, rig, actor)

@router.get("/new", response_class=HTMLResponse)
def stock_new_form(
    ok: bool = Depends(require_reader),
    rig: str = Depends(current_rig_title),
    actor: str = Depends(current_actor),
):
    body = """
      <form method="post" action="/stock/new" class="form">
        <label>Name <input name="name" required></label>
        <label>On-rig qty <input type="number" name="on_rig_qty" value="0"></label>
        <label>Min qty <input type="number" name="min_qty" value="0"></label>
        <label>Buffer qty <input type="number" name="buffer_qty" value="0"></label>
        <label>Unit <input name="unit" value="ea"></label>
        <label>Location <input name="location"></label>
        <div class="actions">
          <button class="btn" type="submit">Save</button>
          <a class="btn" href="/stock">Cancel</a>
        </div>
      </form>
    """
    return _wrap("New Stock Item", body, rig, actor)

@router.post("/new")
def stock_new(
    actor: str = Depends(current_actor),
    name: str = Form(...),
    on_rig_qty: int = Form(0),
    min_qty: int = Form(0),
    buffer_qty: int = Form(0),
    unit: str = Form("ea"),
    location: str = Form(""),
    db=Depends(get_db),
):
    s = StockItem(
        name=name, on_rig_qty=on_rig_qty, min_qty=min_qty, buffer_qty=buffer_qty,
        unit=unit, location=(location or None)
    )
    db.add(s)
    db.commit()
    write_log(db, actor=actor or "crew", entity="stock", entity_id=s.id, action="create", summary=name)
    return RedirectResponse("/stock", status_code=303)

@router.post("/{stock_id}/delete")
def stock_delete(
    stock_id: int,
    actor: str = Depends(current_actor),
    db=Depends(get_db),
):
    s = db.get(StockItem, stock_id)
    if s:
        name = s.name
        db.delete(s)
        db.commit()
        write_log(db, actor=actor or "crew", entity="stock", entity_id=stock_id, action="delete", summary=name or "")
    return RedirectResponse("/stock", status_code=303)

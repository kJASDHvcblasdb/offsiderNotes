from __future__ import annotations

from fastapi.responses import HTMLResponse

def wrap_page(
    *,
    title: str,
    body_html: str,
    actor: str | None = None,
    rig_title: str | None = None,
) -> HTMLResponse:
    who = []
    if rig_title:
        who.append(f"Rig: <strong>{rig_title}</strong>")
    if actor:
        who.append(f"Crew: <strong>{actor}</strong>")
    who_html = f"<p class='muted'>{' · '.join(who)}</p>" if who else ""

    html = f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/static/style.css">
    <title>{title}</title>
  </head>
  <body class="container">
    <h1>{title}</h1>
    {who_html}

    {body_html}

    <footer class="footer">
      <a class="btn" href="/">⬅ Back to Dashboard</a>
      <a class="btn" href="/audit">Audit</a>
    </footer>
  </body>
</html>
"""
    return HTMLResponse(html)

from __future__ import annotations

from pathlib import Path
from typing import List

from fastapi import Depends, FastAPI
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select
from sqlalchemy.exc import OperationalError
from starlette.middleware.base import BaseHTTPMiddleware

from .db import get_db, ensure_db_initialized_with_seed
from .models import (
    Settings,
    StockItem,
    RestockItem,
    Bit,
    BitStatus,
    EquipmentFault,
)

# Auth + rig/actor deps and router
from .auth import (
    router as auth_router,
    require_reader,
    current_actor,
    current_rig_id,
    current_rig_title,
)

# Feature routers
from .routers.stock import router as stock_router
from .routers.restock import router as restock_router
from .routers.bits import router as bits_router
from .routers.usage import router as usage_router
from .routers.shrouds import router as shrouds_router
from .routers.equipment import router as equipment_router
from .routers.travel import router as travel_router
from .routers.refuel import router as refuel_router
from .routers.handover import router as handover_router

# Recent activity helper
from .audit import recent_logs


app = FastAPI(title="Rig App", version="0.1")

# ---- Static / CSS ------------------------------------------------------------

app.mount(
    "/static",
    StaticFiles(directory=Path(__file__).parent / "static"),
    name="static",
)


class AutoCSSMiddleware(BaseHTTPMiddleware):
    """
    Injects viewport meta + /static/style.css into any HTML-like response.
    Also normalizes Content-Type to text/html if the body looks like HTML.
    """

    async def dispatch(self, request, call_next):
        resp = await call_next(request)

        # Pull body from buffered responses (HTMLResponse/Response)
        body_bytes = None
        try:
            if hasattr(resp, "body"):
                b = resp.body
                if isinstance(b, (bytes, bytearray)):
                    body_bytes = bytes(b)
                elif isinstance(b, str):
                    body_bytes = b.encode(getattr(resp, "charset", "utf-8"), "ignore")
        except Exception:
            body_bytes = None

        if body_bytes is None:
            return resp  # can't safely modify

        # Determine if it's HTML or looks like it
        ctype = (resp.headers.get("content-type") or "").lower()
        looks_html = False
        try:
            probe = body_bytes[:256].decode(getattr(resp, "charset", "utf-8"), "ignore").lower()
            looks_html = ("<html" in probe) or ("<body" in probe)
        except Exception:
            pass

        if ("text/html" not in ctype) and not looks_html:
            return resp

        # Decode full body
        try:
            charset = getattr(resp, "charset", "utf-8")
            text = body_bytes.decode(charset, "ignore")
        except Exception:
            return resp

        lower = text.lower()
        has_head = "<head" in lower
        has_css = "static/style.css" in lower

        if has_head and has_css:
            # Already styled; normalize content-type if needed
            if "text/html" not in ctype:
                return HTMLResponse(text, status_code=resp.status_code, headers=dict(resp.headers))
            return resp

        head_snippet = (
            "<head>"
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            '<link rel="stylesheet" href="/static/style.css">'
            "</head>"
        )

        if not has_head:
            idx_html = lower.find("<html")
            if idx_html != -1:
                idx_close = lower.find(">", idx_html)
                if idx_close != -1:
                    text = text[: idx_close + 1] + head_snippet + text[idx_close + 1 :]
                else:
                    text = "<html>" + head_snippet + text
            else:
                idx_body = lower.find("<body")
                if idx_body != -1:
                    text = text[:idx_body] + head_snippet + text[idx_body:]
                else:
                    text = head_snippet + text
        else:
            text = text.replace(
                "<head>",
                "<head>"
                '<meta name="viewport" content="width=device-width, initial-scale=1">'
                '<link rel="stylesheet" href="/static/style.css">',
                1,
            )

        return HTMLResponse(text, status_code=resp.status_code, headers=dict(resp.headers))


app.add_middleware(AutoCSSMiddleware)

# ---- Startup: ensure DB/tables/seed exist -----------------------------------

@app.on_event("startup")
def _startup_init_db():
    ensure_db_initialized_with_seed()


# ---- Routers -----------------------------------------------------------------

app.include_router(auth_router)
app.include_router(stock_router)
app.include_router(restock_router)
app.include_router(bits_router)
app.include_router(usage_router)
app.include_router(shrouds_router)
app.include_router(equipment_router)
app.include_router(travel_router)
app.include_router(refuel_router)
app.include_router(handover_router)


# ---- Health / Debug ----------------------------------------------------------

@app.get("/health")
def health() -> JSONResponse:
    return JSONResponse({"status": "ok"})


@app.get("/debug/routes")
def debug_routes():
    routes: List[dict] = []
    for r in app.router.routes:
        name = getattr(r, "name", "")
        path = getattr(r, "path", "")
        routes.append({"path": path, "name": name})
    return routes


@app.get("/debug/settings")
def debug_settings(db=Depends(get_db)):
    s = db.scalar(select(Settings).limit(1))
    return {
        "status": "ok",
        "timezone": s.timezone if s else None,
        "reminder_horizon_days": s.reminder_horizon_days if s else None,
        "has_pin_hash": bool(s and s.crew_pin_hash),
    }


@app.get("/debug/db-check")
def debug_db_check(db=Depends(get_db)):
    """
    Sanity probe to confirm tables are present and simple selects work.
    """
    try:
        _ = db.scalar(select(Settings).limit(1))
        _ = db.scalar(select(StockItem.id).limit(1))
        _ = db.scalar(select(Bit.id).limit(1))
        _ = db.scalar(select(EquipmentFault.id).limit(1))
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": repr(e)}


# ---- Admin (manual init) -----------------------------------------------------

@app.post("/admin/init")
def admin_init() -> JSONResponse:
    """
    Manual trigger to initialize/seed the DB. Idempotent.
    """
    ensure_db_initialized_with_seed()
    return JSONResponse({"status": "initialized"})


# ---- Root / Dashboard --------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
def root(
    actor: str = Depends(current_actor),
    rig_id: str = Depends(current_rig_id),
    rig_title: str = Depends(current_rig_title),
    db=Depends(get_db),
):
    # not logged in? choose a rig + sign in
    if not actor or not rig_id:
        return RedirectResponse("/auth/select", status_code=303)

    try:
        # Priority/attention signals
        low_stock = db.scalars(
            select(StockItem).where(StockItem.on_rig_qty <= (StockItem.min_qty + StockItem.buffer_qty))
        ).all()
        open_restock = db.scalars(
            select(RestockItem).where(RestockItem.is_closed == False)  # noqa: E712
        ).all()
        bits_attention = db.scalars(
            select(Bit).where(Bit.status.in_([BitStatus.NEEDS_RESHARPEN, BitStatus.VERY_USED]))
        ).all()
        open_faults = db.scalars(
            select(EquipmentFault).where(EquipmentFault.is_resolved == False)  # noqa: E712
        ).all()
    except OperationalError as e:
        msg = (
            "<html><head><link rel='stylesheet' href='/static/style.css'></head>"
            "<body class='container'>"
            "<h1>Database not initialized</h1>"
            "<p class='muted'>Tables are missing. "
            "Click the button below to initialize and seed the database, then reload.</p>"
            "<form method='post' action='/admin/init'><button type='submit'>Initialize DB</button></form>"
            f"<pre style='margin-top:1rem;'>{str(e)}</pre>"
            "</body></html>"
        )
        return HTMLResponse(msg, status_code=500)

    # Attention cards
    attention_cards = []
    attention_cards.append(
        "<a class='card' href='/stock' style='border-left:6px solid #8b0000;'>"
        "<strong>Low/Critical stock</strong><br><span class='muted'>"
        f"{len(low_stock)} items</span></a>"
    )
    attention_cards.append(
        "<a class='card' href='/restock' style='border-left:6px solid #1f6feb;'>"
        "<strong>Open restock</strong><br><span class='muted'>"
        f"{len(open_restock)} entries</span></a>"
    )
    attention_cards.append(
        "<a class='card' href='/bits' style='border-left:6px solid #f9844a;'>"
        "<strong>Bits attention</strong><br><span class='muted'>"
        f"{len(bits_attention)} items</span></a>"
    )
    attention_cards.append(
        "<a class='card' href='/equipment' style='border-left:6px solid #e0a800;'>"
        "<strong>Open equipment faults</strong><br><span class='muted'>"
        f"{len(open_faults)} open</span></a>"
    )

    # Quick links (cards; only “Add …” actions)
    quick_cards = """
      <div class="cards">
        <a class="card" href="/stock/new"><strong>➕ Add stock item</strong><br><span class="muted">Name, unit, mins</span></a>
        <a class="card" href="/restock/new"><strong>➕ Add restock item</strong><br><span class="muted">Link to stock, priority</span></a>
        <a class="card" href="/bits/new"><strong>➕ Add bit</strong><br><span class="muted">Serial, status, shroud</span></a>
        <a class="card" href="/equipment/new"><strong>➕ Add equipment</strong><br><span class="muted">Checks & faults</span></a>
        <a class="card" href="/handover/new"><strong>➕ Add handover note</strong><br><span class="muted">With priority</span></a>
        <a class="card" href="/travel/new"><strong>➕ Add travel log</strong><br><span class="muted">Where/when</span></a>
        <a class="card" href="/refuel/new"><strong>➕ Add refuel log</strong><br><span class="muted">Before/after, time</span></a>
      </div>
    """

    # Sections grid (navigation tiles)
    sections_grid = """
      <div class="cards">
        <a class="card" href="/stock"><strong>Stock</strong><br><span class="muted">On-rig, min/buffer, priorities</span></a>
        <a class="card" href="/restock"><strong>Restock</strong><br><span class="muted">Checklist & planning</span></a>
        <a class="card" href="/bits"><strong>Bits & Shrouds</strong><br><span class="muted">Serials, status, usage</span></a>
        <a class="card" href="/usage"><strong>Daily Usage</strong><br><span class="muted">Consumption logs</span></a>
        <a class="card" href="/equipment"><strong>Equipment</strong><br><span class="muted">Checks & faults</span></a>
        <a class="card" href="/handover"><strong>Handover</strong><br><span class="muted">Notes & priorities</span></a>
        <a class="card" href="/travel"><strong>Travel</strong><br><span class="muted">Location/time log</span></a>
        <a class="card" href="/refuel"><strong>Refuel</strong><br><span class="muted">Before/after & reminders</span></a>
      </div>
    """

    # Recent activity
    entries = recent_logs(db, limit=10)
    log_rows = []
    for e in entries:
        when = e.created_at.strftime("%Y-%m-%d %H:%M") if getattr(e, "created_at", None) else ""
        summary = (e.summary or "").replace("<", "&lt;")
        log_rows.append(
            f"<tr><td>#{e.id}</td><td>{when}</td><td>{e.actor}</td>"
            f"<td>{e.entity}[{e.entity_id}] {e.action}</td><td><small>{summary}</small></td></tr>"
        )
    recent_html = (
        "<p class='muted'>No recent activity.</p>"
        if not log_rows
        else "<table><thead><tr><th>ID</th><th>When</th><th>Actor</th><th>What</th><th>Summary</th></tr></thead>"
             f"<tbody>{''.join(log_rows)}</tbody></table>"
    )

    # Explicit head ensures the dashboard is styled
    title = (rig_title or rig_id or "Rig") + " Dashboard"
    html = f"""
    <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="/static/style.css">
        <title>{title}</title>
      </head>
      <body class="container">
        <h1>{title}</h1>
        <p class="muted">Signed in as <strong>{actor}</strong>.
          <form class="noprint" method="post" action="/auth/logout" style="display:inline;">
            <button type="submit">Sign out</button>
          </form>
        </p>

        <h2>Attention</h2>
        <div class="cards">
          {''.join(attention_cards)}
        </div>

        <h2>Quick links</h2>
        {quick_cards}

        <h2>Sections</h2>
        {sections_grid}

        <h2 style="margin-top:2rem;">Recent Activity</h2>
        {recent_html}

        <p style="margin-top:1rem;"><a href="/docs" class="muted">API docs</a></p>
      </body>
    </html>
    """
    return HTMLResponse(html)
